<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sidebar Pelanggan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            overflow: hidden;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div id="sidebar" class="fixed top-0 left-0 h-full w-[55%] md:w-[18%] bg-[#FADA7A] shadow-lg transform -translate-x-full transition-transform duration-300 z-50">
    <div class="p-0">
        <ul class="mt-0">
            <!-- Beranda -->
            <li class="sidebar-item py-5 hover:bg-[#FFF6DA]" data-page="home">
                <a href="/pelanggan/home" class="flex items-center gap-3 pl-5 font-medium md:gap-7">
                    <img src="/images/beranda-pelanggan-hitam.png" alt="gambar" class="w-7 h-7 md:w-10 md:h-10">
                    <span class="inline md:inline text-[14px] md:text-lg">Beranda</span>
                </a>
            </li>

            <!-- Menu -->
            <li class="sidebar-item py-5 group hover:bg-[#FFF6DA]" data-page="menu">
                <a href="/pelanggan/menu-makanan" class="flex items-center gap-3 pl-5 font-medium md:gap-7">
                    <img src="/images/menu-pelanggan-hitam.png" alt="gambar" class="w-7 h-7 md:w-10 md:h-10">
                    <span class="inline md:inline text-[14px] md:text-lg">Menu</span>
                </a>
            </li>

            <!-- Riwayat Pesanan -->
            <li class="sidebar-item py-5 group hover:bg-[#FFF6DA]" data-page="riwayat-pesanan">
                <a href="/pelanggan/pesanan-riwayatpesanan" class="flex items-center gap-3 pl-5 font-medium md:gap-7">
                    <img src="/images/pesanan-pelanggan-hitam.png" alt="gambar" class="w-7 h-7 md:w-10 md:h-10">
                    <span class="inline md:inline text-[14px] md:text-lg">Riwayat Pesanan</span>
                </a>
            </li>

            <!-- Split Bill -->
            <li class="sidebar-item py-5 group hover:bg-[#FFF6DA]" data-page="splitbill-scan">
                <a href="/pelanggan/splitbill-scan" class="flex items-center gap-3 pl-5 font-medium md:gap-7">
                    <img src="/images/splitbill-pelanggan-hitam.png" alt="gambar" class="w-7 h-7 md:w-10 md:h-10">
                    <span class="inline md:inline text-[14px] md:text-lg">Split bill</span>
                </a>
            </li>
        </ul>
    </div>
</div>


<!-- Tombol Close di Atas Overlay -->
<button id="closeBtn"
    class="absolute left-[55%] top-[0%] md:top-[0%] md:left-[18%] text-2xl py-5 px-4 md:py-5 md:px-5 bg-[#FADA7A] hover:bg-[#FFF6DA] hidden z-50"
    onclick="toggleSidebar()">
    <img src="/images/close-sidebar.png" alt="gambar" class="w-7 h-7 md:w-10 md:h-10">
</button>

 <script>
    //Menampilkan dan Menutup Sidebar
    function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const closeBtn = document.getElementById('closeBtn');

    const isHidden = sidebar.classList.contains('-translate-x-full');

    if (isHidden) {
        sidebar.classList.remove('-translate-x-full');
        overlay.classList.remove('hidden');
        closeBtn.classList.remove('hidden');
    } else {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
        closeBtn.classList.add('hidden');
        }
    }

    // Menyimpan Background Sidebar yang di Klik
    document.addEventListener("DOMContentLoaded", function () {
    const sidebarItems = document.querySelectorAll(".sidebar-item");
    const activePage = localStorage.getItem("activeSidebar");

    if (activePage) {
        document.querySelector(`[data-page="${activePage}"]`)?.classList.add("bg-[#FFF6DA]");
    }

    sidebarItems.forEach(item => {
        item.addEventListener("click", function () {
            sidebarItems.forEach(i => i.classList.remove("bg-[#FFF6DA]"));

            this.classList.add("bg-[#FFF6DA]");

            localStorage.setItem("activeSidebar", this.getAttribute("data-page"));
        });
    });
});
</script>

</body>
</html>
