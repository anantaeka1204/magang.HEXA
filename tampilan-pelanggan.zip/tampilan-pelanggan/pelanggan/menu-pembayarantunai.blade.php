<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Pembayaran Tunai 2)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="relative bg-gray-100 pt-[50px] md:pt-[95px]">
  <!-- Overlay Blur -->
  <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

  @extends('layout.master-pelanggan2')

   @section('content')

    <!-- Container -->
<div class="relative p-4 content md:p-6">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 pt-5">

        <!-- Info Tanggal Pembayaran -->
        <div class="mt-0">
            <h2 class="text-[16px] md:text-[18px] font-medium">Menunggu Pembayaran</h2>
            <p class="text-[14px] md:text-[16px]  font-normal">Bayar Sebelum: 08:53, 02 Feb 2025</p>
        </div>

        <div class="pt-5">
            <hr class="border-black border-1">
        </div>

        <div class="space-y-4">
            <div class="flex items-center justify-between mt-4">
                <h2 class="text-lg font-medium">Item Detail</h2>
            </div>
            <!-- Pesanan 1 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[14px] md:text-[16px] font-normal">Bakso Campur</span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-10">
                            <span class="text-[14px] md:text-[16px] font-normal">1x</span>
                            <span class="ml-auto text-[14px] md:text-[16px] font-normal">Rp15.000</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan 2 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/mie ayam.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-sm font-normal">Mie Ayam</span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-10">
                            <span class="text-sm font-normal">1x</span>
                            <span class="ml-auto text-sm font-normal">Rp15.000</span>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Pesanan 3 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/es teh.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-sm font-normal">Es Teh</span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-10">
                            <span class="text-sm font-normal">1x</span>
                            <span class="ml-auto text-sm font-normal">Rp6.000</span>
                        </div>
                    </div>

                </div>

        </div>

        <!-- Total -->
        <div class="pt-2 mt-4">
            <hr class="border-black border-1">
            <div class="flex items-center justify-between pt-5 pb-5">
                <p class="font-medium text-[12px] md:text-[14px] ">Total</p>
                <span class="font-medium text-[12px] md:text-[14px] ">Rp 35.000</span>
            </div>
            <hr class="border-black border-1">

             <!-- Tombol Cek Status Pembayaran -->
            <div class="relative bottom-0 left-0 w-full mt-[200px]">
                <a href="/pelanggan/pesanan-livetracking"
                class="bg-[#FADA7A] hover:bg-[#F2E5BF] w-full text-[14px] md:text-[16px] text-center font-medium px-4 py-3 rounded-full block">
                    Cek Status Pembayaran
                </a>
            </div>
        </div>

    </div>

    @endsection

</body>
</html>
