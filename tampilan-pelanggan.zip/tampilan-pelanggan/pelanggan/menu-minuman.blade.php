<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Menu Minuman)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .set-scroll{
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
    </head>
<body class="bg-[#FFFFFF] relative pt-[50px] md:pt-[95px]">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan')

   @section('content')

    <!-- Container -->
    <div class="relative p-4 md:p-6 content">

        <!-- Button Menu Kategori -->
        <h2 class="text-[16px] md:text-[18px] text-center font-medium mb-3">Menu</h2>
            <div class="mb-3 overflow-x-auto set-scroll whitespace-nowrap">
                <div class="flex space-x-4 flex-nowrap">
                    <a href="/pelanggan/menu-makanan" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A]  border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/makanan-pelanggan.png" alt="Makanan"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Makanan</span>
                    </a>
                    <a href="/pelanggan/menu-minuman" class="menu-makanan bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/minuman-pelanggan.png" alt="Minuman"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Minuman</span>
                    </a>
                    <a href="/pelanggan/menu-snack" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/snack-pelanggan.png" alt="Snack"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Snack</span>
                    </a>
                </div>
            </div>



        <!-- Menu Minuman -->
        <div class="grid grid-cols-1 gap-4 pt-2 md:grid-cols-2">

            <!-- Menu Minuman 1 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/air mineral.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Air Mineral</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 3.000</p>
                        <div id="orderButtonContainer5">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(5)" class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                                Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Menu Minuman 2 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/teh hangat.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Teh Hangat</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 2.000</p>
                        <div id="orderButtonContainer6">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(6)" class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                                Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Menu Minuman 3 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/es teh.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Es Teh</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 3.000</p>
                        <div id="orderButtonContainer7">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(7)" class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                                Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Menu Minuman 4 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/jeruk hangat.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Jeruk Hangat</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 4.000</p>
                        <div id="orderButtonContainer8">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(8)" class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                                Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Menu Minuman 5 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/es jeruk.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Es Jeruk</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 4.000</p>
                        <div id="orderButtonContainer9">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(9)" class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                                Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Menu Minuman 6 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[125px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/jus jambu.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] saturate-0 h-full rounded-2xl object-cover opacity-70">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-3">
                    <h2 class="text-[14px] md:text-[18px] font-medium text-[#686D76]">Jus Jambu</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-[#686D76] font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                        <p class="px-3 py-1 rounded-full text-[12px] md:text-[16px] text-[#BB1717] font-medium transition-colors duration-200">
                            Stock Habis
                        </p>
                    </div>
                </div>
            </div>



    </div>

    @endsection

    <script>
    // Mengubah ketika user membuat sebuah pesanan
    function saveItemId(itemId) {
        sessionStorage.setItem('currentItem', itemId);
    }

    function updateOrderButtons() {
        for (let i = 1; i <= 1000; i++) { // Loop untuk 1000 menu
            let count = localStorage.getItem('orderedItem' + i);
            let container = document.getElementById('orderButtonContainer' + i);

            if (count && container) {
                container.innerHTML = `
                <div class="flex items-center bg-[#B8D576] w-[75px] h-[25px] md:w-[100px] md:h-[33px] gap-2 rounded-full border border-1">
                    <div class="flex items-center gap-0 ml-3 md:ml-3 md:gap-[2px]">
                        <button class="text-[20px]" onclick="decreaseCount(${i})">-</button>
                        <span id="count${i}" class="mx-1 text-[12px] md:text-[14px] font-medium md:mx-3 min-w-[24px] text-center">${count}</span>
                        <button class="text-[20px]" onclick="increaseCount(${i})">+</button>
                    </div>
                </div>
                `;
            }
        }
    }

    function increaseCount(itemId) {
        let count = parseInt(localStorage.getItem('orderedItem' + itemId) || 1);
        localStorage.setItem('orderedItem' + itemId, count + 1);
        document.getElementById('count' + itemId).innerText = count + 1;
    }

    function decreaseCount(itemId) {
        let count = parseInt(localStorage.getItem('orderedItem' + itemId) || 1);
        if (count > 1) {
            localStorage.setItem('orderedItem' + itemId, count - 1);
            document.getElementById('count' + itemId).innerText = count - 1;
        } else {
            localStorage.removeItem('orderedItem' + itemId);
            location.reload(); // Reload halaman untuk mengembalikan tombol "Tambah"
        }
    }

    // Perbarui tampilan tombol saat halaman dimuat
    document.addEventListener('DOMContentLoaded', updateOrderButtons);
    </script>


</body>
</html>
