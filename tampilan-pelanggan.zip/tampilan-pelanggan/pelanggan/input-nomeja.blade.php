<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Input No Meja)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .hero {
        background: linear-gradient(to bottom, #FADA7A 20%, #FFFFFF 100%);
        }

        @media screen and (max-width: 768px) {
        .hero {
            background: linear-gradient(to bottom, #FADA7A  20%, #FFFFFF 100%);
        }

        }

    </style>
</head>
<body class="bg-[#FFFFFF] relative pt-[50px] md:pt-[95px]">

   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan')

   @section('content')

    <div class="relative content">

        <!--Hero-->
        <div class="flex flex-row items-center justify-between gap-5 py-20 hero md:py-10">
             <!-- Teks -->
             <p class="hero-text font-medium flex text-center text-[16px] md:text-[20px] w-[50%] md:w-[50%] p-4 md:p-6 transform translate-x-0 md:translate-x-[200px]">
                Selamat Datang di Tapeats!
            </p>

            <!-- Gambar Orang -->
            <div class="hero-gambar flex items-center w-[30%] md:w-[20%]">
                <img src="/images/orang-inputnomeja.png" alt="gambar"
                    class="w-[159px] h-[170px] md:w-60 md:h-60 object-cover transform -translate-x-[40px] md:-translate-x-[200px]">
            </div>
        </div>


        <div class="p-4 pt-2 md:p-6">
        <div class="flex flex-col w-full space-y-3">

            <h2 class=" text-[16px] md:text-[18px] font-medium pt-5 pb-2">Masukkan Nomor Meja Anda</h2>
            <div class="search-pelanggan flex items-center bg-[#E5E1DA] rounded-3xl w-full p-2 md:p-3 border border-1">
                <input type="text" placeholder="Contoh : 01"
                    class="flex-1 bg-transparent outline-none pl-4 md:pl-6 placeholder-black text-[14px] md:text-[16px] md:text-base font-thin">
            </div>

            <div class="fixed bottom-0 left-0 w-full p-4 md:p-6">
                <a href="/pelanggan/home"
                   class="bg-[#FADA7A] hover:bg-[#FFF6DA] w-full text-[14px] md:text-[16px] py-2 md:py-3 rounded-full
                          text-center flex items-center justify-center font-medium">
                    Selanjutnya
                </a>
            </div>
        </div>
        </div>

        @endsection

    </div>

</body>
</html>
