<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Menu Detail)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF] relative pt-[50px] md:pt-[95px]">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')


    <div class="relative flex flex-col h-screen p-4 md:p-6">

        <!-- Gambar -->
        <div class="flex justify-center mb-4">
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[165px] h-[165px] md:w-[165px] md:h-[165px] rounded-lg object-cover">
        </div>

        <!-- Info Makanan -->
        <hr class="border-black border-1">
        <div class="mt-3">
            <div class="flex items-center justify-between">
                <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                <span class="text-[14px] md:text-[18px] font-medium text-gray-700">Rp 15.000</span>
            </div>
            <p class="text-[12px] md:text-[16px] mb-3 font-normal">Isi: Pentol, tahu, gorengan</p>
        </div>

        <hr class="border-black border-1">

        <!-- Catatan -->
        <div class="mt-4">
            <div class="flex items-center justify-between pb-0">
                <label for="catatan" class="text-[14px] md:text-[16px] pb-5 font-normal">Catatan Untuk Resto</label>
                <span id="char-count" class="text-[12px] md:text-[16px] pb-5 font-normal">0/100</span>
            </div>
            <textarea id="catatan" class="w-full h-32 p-3 border rounded-lg bg-[#E5E1DA] text-[12px] font-light resize-none focus:outline-none placeholder-black text-black" maxlength="100" placeholder="Silakan bagikan informasi..." ></textarea>
        </div>

        <!--Tombol Tambahkan Pembelian-->
        <div class="bg-[#FADA7A] rounded-full w-full mb-2 p-2 mt-auto">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-5 ml-3">
                    <!-- Tombol - -->
                    <button class="flex items-center justify-center w-8 h-8 border-2 border-black rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M20 12H4" />
                        </svg>
                    </button>

                    <!-- Jumlah -->
                    <span class="font-medium text-black">1</span>

                    <!-- Tombol + -->
                    <button class="flex items-center justify-center w-8 h-8 border-2 border-black rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
                        </svg>
                    </button>
                </div>

                <button onclick="confirmOrder()" class="bg-[#FFF6DA] hover:bg-[#F2E5BF] font-medium text-[14px] md:text-[18px] px-2 py-2 rounded-full inline-block">
                    Buat Pesanan
                </button>
            </div>
        </div>
    </div>

</div>

@endsection

<script>
    // Untuk Mendapatkan ID yang dipilih dan kembali ke halaman sebelumnya
   function confirmOrder() {
    let itemId = sessionStorage.getItem('currentItem');
    if (itemId) {
        localStorage.setItem('orderedItem' + itemId, 1);
        sessionStorage.removeItem('currentItem');

        if (document.referrer) {
            window.location.href = document.referrer;
        } else {
            window.history.back();
        }
    }
}

</script>

</body>
</html>
