<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Jumlah Total Per-orang)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF]  relative pt-[50px] md:pt-[95px]">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')

    <!-- Container -->
<div class="relative content">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 p-4 pt-5 md:p-6">

            <h2 class="text-center font-medium text-[16px] md:text-[18px]">Split Bill</h2>
            <hr class="my-2 border-black">

            <!-- Total -->
            <div class="flex items-center justify-between">
                <!-- Bagian Kiri -->
                <div class="flex flex-col justify-center gap-2">
                    <p class="font-medium text-[14px] md:text-[16px]">Jumlah Total</p>
                    <p class="font-normal text-[12px] md:text-[14px]">02 Februari 2025 08:47</p>
                    <p class="font-medium text-[14px] md:text-[16px]">Rp 36.000</p>
                </div>
                <!-- Bagian Kanan (Nomor Transaksi) -->
                <div class="flex flex-col pb-10">
                    <span class="px-3 py-1 font-normal text-[12px] md:text-[14px] bg-[#FADA7A] rounded-full">02022501</span>
                </div>
            </div>


            <hr class="my-2 border-black">

            <!-- Orang Pertama -->
            <div>
                <div class="flex items-center gap-3">
                    <img src="/images/profil.jpg" class="w-10 h-10 rounded-full" alt="User">
                    <div>
                        <p class="font-medium text-[14px] md:text-[16px]">Total tagihan Rafifah</p>
                        <p class="font-medium text-[14px] md:text-[16px]">Rp 18.000</p>
                    </div>
                </div>
                <hr class="my-2">
                <div class="mt-2 space-y-1">
                    <div class="grid grid-cols-3 text-sm">
                        <span class="col-span-1 font-normal text-[12px] md:text-[14px]">Bakso Campur</span>
                        <span class="text-center font-normal text-[12px] md:text-[14px]">1x</span>
                        <span class="text-right font-normal text-[12px] md:text-[14px]">Rp 15.000</span>
                    </div>
                    <div class="grid grid-cols-3 text-sm">
                        <span class="col-span-1 font-normal text-[12px] md:text-[14px]">Es Teh</span>
                        <span class="text-center font-normal text-[12px] md:text-[14px]">1x</span>
                        <span class="text-right font-normal text-[12px] md:text-[14px]">Rp 3.000</span>
                    </div>
                </div>
            </div>

            <hr class="my-4 border-black">

            <!-- Orang Kedua -->
            <div>
                <div class="flex items-center gap-3">
                    <img src="/images/profil.jpg" class="w-10 h-10 rounded-full" alt="User">
                    <div>
                        <p class="font-medium text-[14px] md:text-[16px]">Total tagihan Amel</p>
                        <p class="font-medium text-[14px] md:text-[16px]">Rp 18.000</p>
                    </div>
                </div>
                <hr class="my-2">
                <div class="mt-2 space-y-1">
                    <div class="grid grid-cols-3 text-sm">
                        <span class="col-span-1 font-normal text-[12px] md:text-[14px]">Bakso Campur</span>
                        <span class="text-center font-normal text-[12px] md:text-[14px]">1x</span>
                        <span class="text-right font-normal text-[12px] md:text-[14px]">Rp 15.000</span>
                    </div>
                    <div class="grid grid-cols-3 text-sm">
                        <span class="col-span-1 font-normal text-[12px] md:text-[14px]">Es Teh</span>
                        <span class="text-center font-normal text-[12px] md:text-[14px]">1x</span>
                        <span class="text-right font-normal text-[12px] md:text-[14px]">Rp 3.000</span>
                    </div>
                </div>
            </div>

            <hr class="my-4 border-black">

            <!--Button -->
            <div class="fixed bottom-0 left-0 w-full p-4 md:p-6">
                <a href=""
                class="bg-[#EFB036] hover:bg-[#F2E5BF] p-4 w-full text-black font-sm px-4 py-3 rounded-full
                        text-center flex items-center justify-center font-medium text-[14px] md:text-[16px]">
                        Simpan Splitbill
                </a>
            </div>


    </div>

</div>

@endsection

</body>
</html>
