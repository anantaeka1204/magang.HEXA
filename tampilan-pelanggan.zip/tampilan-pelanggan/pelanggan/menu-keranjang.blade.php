<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Menu Keranjang)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            height: 100%;
        }
    </style>
</head>
<body class="bg-[#FFFFFF] relative pt-[50px] md:pt-[95px]">

<!-- Overlay Blur -->
<div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')

    <div class="relative p-4 md:p-6 content">

        <!--  Dine-In dan No Meja -->
        <div class="flex items-center justify-between px-2 pt-2 pb-4">
            <!-- Dine-In -->
            <div class="flex items-center gap-2">
                <img src="/images/location-pelanggan-hitam.png" alt="gambar" class="w-[25px] h-[25px]">
                <span class="text-[14px] font-medium">Dine-In</span>
            </div>

            <!-- No Meja -->
            <button class="flex items-center gap-2 bg-[#FADA7A] text-black p-1 px-2 rounded-full">
                <img src="/images/meja-pelanggan.png" alt="gambar" class="w-[25px] h-[25px]">
                <span class="font-medium text-[14px]">Meja 04</span>
            </button>

        </div>

    <div class="pt-0 pb-0">
                <hr class="border-black border-1">

            <div class="flex items-center justify-between mt-4">
                <h2 class="font-medium text-[14px] md:[16px]">Item Detail</h2>
                <a href="/pelanggan/menu-makanan" class="text-[14px] md:[16px] text-[#000000] font-normal px-0 py-1 rounded">
                    Tambah Pesanan +
                </a>
            </div>


        <div class="mt-4 space-y-4">
            <!-- Pesanan 1 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Makanan -->
                        <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Makanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[16px] font-normal">Bakso Campur</span>
                                <span class="text-sm font-normal"></span>
                            </div>
                            <button class="text-sm font-normal text-[#000000]">Edit</button>
                        </div>
                        <div class="flex items-center justify-between w-full pt-3">
                            <span class="text-[16px] pt-5 font-normal">Rp 15.000</span>
                            <div class="flex items-center bg-[#B8D576] w-[75px] h-[25px] md:w-[100px] md:h-[33px] gap-2 rounded-full border border-1">
                                <div class="flex items-center gap-0 ml-3 md:ml-3 md:gap-[2px]">
                                    <button class="text-[20px]">-</button>
                                    <span id="count${i}" class="mx-1 text-[12px] md:text-[14px] font-medium md:mx-3 min-w-[24px] text-center">1</span>
                                    <button class="text-[20px]">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan 2 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Makanan -->
                        <img src="/images/mie ayam.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Makanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[16px] font-normal">Mie Ayam</span>
                                <span class="text-sm font-normal"></span>
                            </div>
                            <button class="text-sm font-normal text-[#000000]">Edit</button>
                        </div>
                        <div class="flex items-center justify-between w-full pt-3">
                            <span class="text-[16px] pt-5 font-normal">Rp 15.000</span>
                            <div class="flex items-center bg-[#B8D576] w-[75px] h-[25px] md:w-[100px] md:h-[33px] gap-2 rounded-full border border-1">
                                <div class="flex items-center gap-0 ml-3 md:ml-3 md:gap-[2px]">
                                    <button class="text-[20px]">-</button>
                                    <span id="count${i}" class="mx-1 text-[12px] md:text-[14px] font-medium md:mx-3 min-w-[24px] text-center">1</span>
                                    <button class="text-[20px]">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan 3 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Makanan -->
                        <img src="/images/es teh.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Makanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[16px] font-normal">Es Teh</span>
                                <span class="text-sm font-normal"></span>
                            </div>
                            <button class="text-sm font-normal text-[#000000]">Edit</button>
                        </div>
                        <div class="flex items-center justify-between w-full pt-3">
                            <span class="text-[16px] pt-5 font-normal">Rp 6.000</span>
                            <div class="flex items-center bg-[#B8D576] w-[75px] h-[25px] md:w-[100px] md:h-[33px] gap-2 rounded-full border border-1">
                                <div class="flex items-center gap-0 ml-3 md:ml-3 md:gap-[2px]">
                                    <button class="text-[20px]">-</button>
                                    <span id="count${i}" class="mx-1 text-[12px] md:text-[14px] font-medium md:mx-3 min-w-[24px] text-center">1</span>
                                    <button class="text-[20px]">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Pilih Pembayaran -->
        <div class="p-2 pt-2 mt-4">
            <hr class="pb-2 border-black border-1">

            <p class="text-md">Pilih Pembayaran</p>

            <!-- Radio Button Pilih Pembayaran -->
            <div class="flex gap-20 mt-5 mb-5 space-x-6">
                <label class="flex items-center space-x-2 cursor-pointer">
                    <input type="radio" name="payment" value="Qris" class="w-5 h-5">
                    <span>Qris</span>
                </label>

                <label class="flex items-center space-x-2 cursor-pointer">
                    <input type="radio" name="payment" value="Tunai" class="w-5 h-5">
                    <span>Tunai</span>
                </label>
            </div>

            <hr class="pt-2 border-black border-1">

                <div class="relative bottom-0 left-0 w-full mt-[200px]">
                    <div class="bg-[#FADA7A] flex justify-between items-center rounded-full w-full px-4 py-2">
                        <div class="flex flex-col text-[14px] font-normal">
                            <span>Total</span>
                            <span class="font-semibold">Rp 36.000</span>
                        </div>
                        <a id="order-button" href="#" class="bg-[#FFF6DA] hover:bg-[#F2E5BF] text-[14px] md:text-[16px] px-4 py-2 rounded-full font-normal">
                            Buat Pesanan
                        </a>
                    </div>
                </div>


    </div>


    @endsection

        <script>
            //Menentukan Halaman Pembayaran
            document.addEventListener("DOMContentLoaded", function () {
            const paymentOptions = document.querySelectorAll('input[name="payment"]');
            const orderButton = document.querySelector('#order-button');

            paymentOptions.forEach(option => {
                option.addEventListener("change", function () {
                    if (this.value === "Qris") {
                        orderButton.setAttribute("href", "/pelanggan/menu-pembayaranqris"); // Halaman Pembayara  Qris
                    } else if (this.value === "Tunai") {
                        orderButton.setAttribute("href", "/pelanggan/menu-pembayarantunai"); // Halaman Pembayaran Tunai
                    }
                });
            });
        });

        </script>

</body>
</html>
