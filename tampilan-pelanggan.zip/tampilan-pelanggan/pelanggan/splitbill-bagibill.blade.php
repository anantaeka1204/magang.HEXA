<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Bagi Bill)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF]  relative pt-[50px] md:pt-[95px]">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')

    <!-- Container -->
<div class="relative p-4 content md:p-6">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 pt-5">
            <!-- Judul -->
            <h2 class="text-center text-[16px] md:text-[18px] font-medium">Split Bill</h2>
            <hr class="my-2 border-black">

            <!-- Tambahkan Item -->
            <div class="flex justify-between py-2">
                <div class="flex flex-col">
                    <p class="text-[14px] md:text-[16px] font-medium pb-1">Tambahkan Item</p>
                    <p class="text-[12px] md:text-[14px] font-normal">Ketuk teman lalu atur item</p>
                </div>

                <!-- Bagian Bagi Rata -->
                <div class="flex flex-col items-start">
                    <div class="pl-8">
                    <button class="px-3 py-1 text-sm border border-black rounded-full border-1">
                        <span>%</span>
                    </button>
                    </div>
                    <span class="text-[12px] md:text-[14px] font-normal mt-1">Bagi Rata</span>
                </div>
            </div>


            <hr class="my-0 border-black">

            <!-- Daftar Item -->
            <div class="space-y-2">

                <!-- Item 1 -->
                <div class="flex items-center justify-between px-3 py-2 rounded-lg">
                    <!-- Bagian Kiri -->
                    <div class="flex flex-col gap-1">
                        <p class="font-medium text-[12px] md:text-[14px] pb-2">Bakso Campur</p>
                        <p class="font-light text-[12px] md:text-[14px] pb-1">1x</p>

                        <div class="flex items-center gap-2">
                            <!-- Nama Splitbill -->
                            <div class="relative px-4 bg-[#efb1363a] rounded-lg border border-[#FADA7A]">
                                <span class="text-[14px] md:text-[16px] font-normal">Rafifah</span>
                            </div>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </span>
                        </div>
                    </div>

                    <!-- Bagian Kanan -->
                    <div class="flex flex-col items-end gap-5">
                        <!-- Tombol Tambah Orang -->
                        <button class="relative p-1 bg-[#FADA7A] rounded-full">
                            <img src="/images/tambah-orang.png" alt="Tambah Orang" class="w-[20px] h-[20px] md:w-[25px] md:h-[25px] rounded-full">
                        </button>
                        <!-- Harga -->
                        <p class="font-normal text-[12px] md:text-[14px]">Rp 15.000</p>
                    </div>
                </div>

                <hr class="my-0 border-black">

                <!-- Item 2 -->
                <div class="flex items-center justify-between px-3 py-2 rounded-lg">
                    <!-- Bagian Kiri -->
                    <div class="flex flex-col gap-1">
                        <p class="font-medium text-[12px] md:text-[14px] pb-2">Bakso Campur</p>
                        <p class="font-light text-[12px] md:text-[14px] pb-1">1x</p>

                        <div class="flex items-center gap-2">
                            <!-- Nama Splitbill -->
                            <div class="relative px-4 bg-[#efb1363a] rounded-lg border border-[#FADA7A]">
                                <span class="text-[14px] md:text-[16px] font-normal">Rafifah</span>
                            </div>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </span>
                        </div>
                    </div>

                    <!-- Bagian Kanan -->
                    <div class="flex flex-col items-end gap-5">
                        <!-- Tombol Tambah Orang -->
                        <button class="relative p-1 bg-[#FADA7A] rounded-full">
                            <img src="/images/tambah-orang.png" alt="Tambah Orang" class="w-[20px] h-[20px] md:w-[25px] md:h-[25px] rounded-full">
                        </button>
                        <!-- Harga -->
                        <p class="font-normal text-[12px] md:text-[14px]">Rp 15.000</p>
                    </div>
                </div>

                <hr class="my-0 border-black">

                <!-- Item 3 -->
                <div class="flex items-center justify-between px-3 py-2 rounded-lg">
                    <!-- Bagian Kiri -->
                    <div class="flex flex-col gap-1">
                        <p class="font-medium text-[12px] md:text-[14px] pb-2">Bakso Campur</p>
                        <p class="font-light text-[12px] md:text-[14px] pb-1">1x</p>

                        <div class="flex items-center gap-2">
                            <!-- Nama Splitbill -->
                            <div class="relative px-4 bg-[#efb1363a] rounded-lg border border-[#FADA7A]">
                                <span class="text-[14px] md:text-[16px] font-normal">Rafifah</span>
                            </div>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                                </svg>
                            </span>
                        </div>
                    </div>

                    <!-- Bagian Kanan -->
                    <div class="flex flex-col items-end gap-5">
                        <!-- Tombol Tambah Orang -->
                        <button class="relative p-1 bg-[#FADA7A] rounded-full">
                            <img src="/images/tambah-orang.png" alt="Tambah Orang" class="w-[20px] h-[20px] md:w-[25px] md:h-[25px] rounded-full">
                        </button>
                        <!-- Harga -->
                        <p class="font-normal text-[12px] md:text-[14px]">Rp 15.000</p>
                    </div>
                </div>



            </div>

            <hr class="my-4 border-black">

            <!-- Total -->
            <div class="flex items-center justify-between font-semibold">
                <p class="font-medium text-[12px] md:text-[14px]">Total</p>
                <p class="font-medium text-[12px] md:text-[14px]">Rp 36.000</p>
            </div>

            <!--Button Konfirmasi-->
            <div class="fixed bottom-0 left-0 w-full p-4">
                <a href="/pelanggan/splitbill-jumlahtotal"
                class="bg-[#EFB036] hover:bg-[#F2E5BF] p-4 w-full text-black font-sm px-4 py-3 rounded-full
                        text-center flex items-center justify-center font-medium text-[14px] md:text-[16px]">
                        Bagi Bill
                </a>
            </div>
    </div>

</div>

@endsection

</body>
</html>
