<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Layout Master</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header-->
    @include('layout.header-kasir')

    <!--Content-->
    @yield('content')

    <script>
       document.addEventListener("DOMContentLoaded", function () {
    const sidebarItems = document.querySelectorAll(".kasir-header");
    let activePage = localStorage.getItem("activeKasir");

    // Jika ada halaman tersimpan di localStorage, gunakan itu untuk menyorot menu
    if (activePage) {
        sidebarItems.forEach(item => {
            item.classList.remove("bg-[#FADA7A]");
            if (item.getAttribute("href") === activePage) {
                item.classList.add("bg-[#FADA7A]");
            }
        });
    }

    // Tambahkan event listener untuk menyimpan pilihan ke localStorage
    sidebarItems.forEach(item => {
        item.addEventListener("click", function (event) {
            localStorage.setItem("activeKasir", this.getAttribute("href"));

            // Hapus warna dari semua item dan tambahkan ke yang diklik
            sidebarItems.forEach(i => i.classList.remove("bg-[#FADA7A]"));
            this.classList.add("bg-[#FADA7A]");
        });
    });
});

    </script>

</body>
</html>
