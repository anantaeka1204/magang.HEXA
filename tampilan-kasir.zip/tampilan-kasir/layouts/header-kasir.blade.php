
    <header id="header-kasir" class="flex justify-between items-center px-6 bg-white shadow-lg h-[100px]">
        <!-- Hallo Kasir -->
        <h1 class="font-bold text-[18px] text-black ml-[30px] mr-[50px]">Hallo Kasir</h1>
        <!-- Garis Vertikal -->
        <div class="w-[1px] h-[100px] bg-black self-stretch mr-[300px]"></div>

        <!-- Bagian Tengah: Navigasi -->
        <nav class="flex items-center space-x-[300px] mr-auto">
            <!-- Menu (Active) -->
            <a href="/kasir/menusemua-kasir" data-page="kasir-menu" class="kasir-header flex items-center px-[30px] space-x-4 text-black hover:bg-[#FADA7A] rounded-lg py-[10px]">
                <img src="/images/menu-kasir.png" alt="gambar" class="w-[40px] h-[40px]">
                <span class="text-[16px] font-medium">Menu</span>
            </a>

            <!-- Riwayat Pesanan -->
            <a href="/kasir/riwayatpesanan-kasir" data-page="kasir-riwayatpesanan" class="kasir-header flex items-center px-[30px] space-x-4 text-black hover:bg-[#FADA7A] rounded-lg py-[10px]">
                <img src="/images/riwayatpesanan-kasir.png" alt="gambar" class="w-[40px] h-[40px]">
                <span class="text-[16px] font-medium">Riwayat Pesanan</span>
            </a>
        </nav>

        <!-- Profil -->
        <div class="flex items-center mr-[20px] gap-4">
            <a href="pesanmenu-kasir" class="py-[5px] px-[10px] bg-[#FADA7A] rounded-md text-[14px] inline-flex items-center gap-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                </svg>
            </a>
            <a href="#" class="py-[5px] px-[10px] bg-[#BB1717] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center gap-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-9a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 4.5 21h9a2.25 2.25 0 0 0 2.25-2.25V15" />
                    <path stroke-linecap="round" stroke-linejoin="round" d="M18 15l3-3m0 0-3-3m3 3H9" />
                </svg>
                <span class="ml-1 font-medium text-[16px]">Logout</span>
            </a>
            <!-- Foto Profil -->
            <img id="profileButton" src="/images/profil.jpg" alt="Profil" class="object-cover w-[44px] h-[44px] rounded-full cursor-pointer">
        </div>

    </header>

    <script>
       document.addEventListener("DOMContentLoaded", function () {
    const sidebarItems = document.querySelectorAll(".kasir-header");
    let activePage = localStorage.getItem("activeKasir");

    // Jika ada halaman tersimpan di localStorage, gunakan itu untuk menyorot menu
    if (activePage) {
        sidebarItems.forEach(item => {
            item.classList.remove("bg-[#FADA7A]");
            if (item.getAttribute("href") === activePage) {
                item.classList.add("bg-[#FADA7A]");
            }
        });
    }

    // Tambahkan event listener untuk menyimpan pilihan ke localStorage
    sidebarItems.forEach(item => {
        item.addEventListener("click", function (event) {
            localStorage.setItem("activeKasir", this.getAttribute("href"));

            // Hapus warna dari semua item dan tambahkan ke yang diklik
            sidebarItems.forEach(i => i.classList.remove("bg-[#FADA7A]"));
            this.classList.add("bg-[#FADA7A]");
        });
    });
});


//Pop Up Butto  Logout
const profileButton = document.getElementById('profileButton');
    const logoutPopup = document.getElementById('logoutPopup');

    profileButton.addEventListener('click', () => {
        logoutPopup.classList.toggle('hidden');
    });

    // Klik di luar popup untuk menutup
    document.addEventListener('click', (event) => {
        if (!profileButton.contains(event.target) && !logoutPopup.contains(event.target)) {
            logoutPopup.classList.add('hidden');
        }
    });
    </script>



