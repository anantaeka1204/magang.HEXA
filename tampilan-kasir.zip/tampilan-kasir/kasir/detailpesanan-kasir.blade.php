
    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center gap-[30px]">
            <a href="/kasir/riwayatpesanan-kasir">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                </svg>
            </a>
            <span class="font-bold text-[24px] ml-2">Detail Pesanan</span>
        </div>

        <div class="pt-[20px]"></div>

        <div class="pt-2 pb-2 p-14">
            <div class="flex items-center justify-between w-full p-4 border-[#E5E1DA] border rounded-lg">
                <div class="flex flex-col">
                    <strong class="text-gray-800">Antrian Pesanan #105482</strong>
                    <span class="px-2 py-1 mt-1 text-sm text-yellow-700 bg-yellow-100 rounded w-fit">Meja 01</span>
                </div>
                <button class="px-[30px] py-1 text-[14px] text-black rounded bg-[#FFA500]">Menunggu</button>
            </div>
        </div>

        <div class="pt-[20px]"></div>

        <div class="pt-2 pb-2 p-14">
            <div class="w-full p-6 rounded-lg border-[#E5E1DA] border">
                <div class="flex flex-col justify-between md:flex-row">
                    <!-- Bagian Kiri -->
                    <div class="w-full space-y-4 md:w-1/5">
                        <div>
                            <p class="font-semibold">Nama Pelanggan</p>
                            <p class="text-[#5E6470]">Alexandra Bell</p>
                        </div>
                        <div>
                            <p class="font-semibold">Pemesanan</p>
                            <p class="text-[#5E6470]">#105482</p>
                        </div>
                        <div>
                            <p class="font-semibold">Tanggal Pesan</p>
                            <p class="text-[#5E6470]">07 Februari, 2025</p>
                        </div>
                    </div>

                    <!-- Bagian Tabel -->
                    <div class="w-full md:w-4/5">
                        <div class="overflow-hidden border border-gray-200 rounded-lg">
                            <table class="w-full border-collapse">
                                <thead>
                                    <tr class="border-white">
                                        <th class="p-2 text-left">List Menu</th>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <th class="p-2 pl-[500px] text-center">Jumlah</th>
                                        <th class="p-2 pr-3 text-right">Sub Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="border-t">
                                        <td class="p-2">Bakso Campur</td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <td class="p-2 pl-[500px] pr-5 text-center">1</td>
                                        <td class="p-2 pr-3 text-right">Rp. 15.000</td>
                                    </tr>
                                    <tr class="border-t">
                                        <td class="p-2">Rawon</td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <td class="p-2 pl-[500px] pr-5 text-center">3</td>
                                        <td class="p-2 pr-3 text-right">Rp. 22.000</td>
                                    </tr>
                                    <tr class="border-t">
                                        <td class="p-2">Es Teh</td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <td class="p-2 pl-[500px] pr-5 text-center">1</td>
                                        <td class="p-2 pr-3 text-right">Rp. 4.000</td>
                                    </tr>
                                    <tr class="border-t">
                                        <td class="p-2">Jeruk Panas</td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <td class="p-2 pl-[500px] pr-5 text-center">3</td>
                                        <td class="p-2 pr-3 text-right">Rp. 6.000</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr class="bg-gray-100 border-t">
                                        <td class="p-2 pr-5 font-semibold text-left"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <td class="p-2 pr-5 text-right"></td>
                                        <th class="p-2 pr-5 text-right"></th>
                                        <td class="p-2 pl-[500px] pr-5 font-semibold text-center text-[#4358D1]">Total Harga</td>
                                        <td class="p-2 pr-3 font-bold text-right text-[#4358D1]">Rp. 103.000</td>
                                    </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>

                <div class="flex justify-center gap-[70px] mt-6">
                    <button class="px-7 py-1 text-white bg-[#FADA7A] rounded text-[12px]">Konfirmasi Qris</button>
                    <button class="px-7 py-1 text-white bg-[#1408FF] rounded text-[12px]">Unduh Nota</button>
                </div>

            </div>




        </div>


    <div>

    @endsection
