    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center justify-between w-full">
            <!-- Bagian Kiri: Menu & Tambah Menu -->
            <div class="flex items-center space-x-5">
                <span class="text-[24px] font-bold">Menu</span>
                <!-- Button Tambah Menu -->
                <div class="bg-[#ffffff] text-black px-4 py-2 border border-1 rounded-full cursor-pointer hover:bg-[#FADA7A] shadow-md">
                    <a href="/kasir/tambahmenu-kasir">+ Tambah Menu</a>
                </div>
            </div>

            <!-- Search -->
            <div class="search-menu flex items-center px-2 py-2 rounded-3xl shadow-sm w-[226px] border border-1 border-black">
                <input type="text" placeholder="Cari Menu"
                    class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[170px]">
                <!-- Button Search -->
                <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-[20px] h-[20px]">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                </button>
            </div>
        </div>


        <!-- Button Menu Kategori -->
        <hr class="border mt-[20px] border-black/15">

            <div class="pt-[20px] mb-[5px] overflow-x-auto set-scroll whitespace-nowrap">
                <div class="flex space-x-4 flex-nowrap">
                    <a href="/kasir/menumakanan-kasir" class="menu-makanan bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm flex justify-center items-center group transition">
                        <span class="text-[14px] md:text-[16px] font-medium">Semua Menu</span>
                    </a>
                    <a href="" class="menu-makanan  bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/makanan-pelanggan.png" alt="Makanan"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Makanan</span>
                    </a>
                    <a href="" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/minuman-pelanggan.png" alt="Minuman"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Minuman</span>
                    </a>
                    <a href="" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A]  border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/snack-pelanggan.png" alt="Snack"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Snack</span>
                    </a>
                </div>
            </div>


    <p class="font-semibold text-[20px] pt-[50px] pb-[2px] pl-0">Makanan</p>

    <div class="flex items-start pt-4 gap-x-[20px]">

        <!-- Kolom Menu -->
        <div class="w-3/5">
            <div class="h-auto">
            <div class="grid grid-cols-3 gap-4">

            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 5 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Card 6 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            </div>

            <p class="font-semibold text-[20px] pt-[20px] pb-[20px] pl-0">Minuman</p>

            <div class="grid grid-cols-3 gap-4">
            <!-- Card 7 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 8 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 9 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 10 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 11 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 12 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            </div>


            <p class="font-semibold text-[20px] pt-[20px] pb-[20px] pl-0">Snack</p>

            <div class="grid grid-cols-3 gap-4">
            <!-- Card 13 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 14 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 15 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-xs text-gray-500 sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            </div>

            </div>
        </div>


        <div class="w-2/5">
            <div class="relative bg-[#E5E1DA] p-4 rounded-t-[5px] flex items-center justify-center">
                <h2 class="text-xl font-semibold">Pesanan Kamu</h2>
                <button class="absolute text-lg text-gray-500 top-4 right-4"><img src="/images/close-sidebar.png" class="h-[12px] w-[12px]"></button>
            </div>

            <!-- Pesanan -->
            <div class="h-auto p-4 overflow-y-auto rounded-[5px] border-[#E5E1DA] border-[2px]">
                <div class="space-y-[25px]">

                    <!-- Pesanan 1 -->
                    <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[111px] md:h-[125px] relative">
                        <!-- Gambar -->
                        <div class="flex-shrink-0 h-full">
                            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                        </div>

                        <!-- Konten -->
                        <div class="relative flex flex-col flex-1 h-full p-3 md:p-3">

                            <div class="absolute top-0 right-0 mt-2 mr-2">
                                <button id="deleteBtn" class="w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </div>

                            <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                            <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                            <!-- Bagian Harga dan Button -->
                            <div class="flex items-center justify-between gap-4 mt-auto">
                                <div id="orderButtonContainer1" class="absolute bottom-4 right-2 mb-[2px] flex items-center border border-gray-300 rounded-full w-[100px] h-[30px] overflow-hidden">
                                    <button onclick="decreaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-r border-gray-300">−</button>
                                    <span id="quantity" class="w-1/3 text-lg font-semibold text-center">1</span>
                                    <button onclick="increaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-l border-gray-300">+</button>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Pesanan 2 -->
                    <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[111px] md:h-[125px] relative">
                        <!-- Gambar -->
                        <div class="flex-shrink-0 h-full">
                            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                        </div>

                        <!-- Konten -->
                        <div class="relative flex flex-col flex-1 h-full p-3 md:p-3">

                            <div class="absolute top-0 right-0 mt-2 mr-2">
                                <button id="deleteBtn" class="w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </div>

                            <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                            <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                            <!-- Bagian Harga dan Button -->
                            <div class="flex items-center justify-between gap-4 mt-auto">
                                <div id="orderButtonContainer1" class="absolute bottom-4 right-2 mb-[2px] flex items-center border border-gray-300 rounded-full w-[100px] h-[30px] overflow-hidden">
                                    <button onclick="decreaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-r border-gray-300">−</button>
                                    <span id="quantity" class="w-1/3 text-lg font-semibold text-center">1</span>
                                    <button onclick="increaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-l border-gray-300">+</button>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Pesanan 3 -->
                    <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[111px] md:h-[125px] relative">
                        <!-- Gambar -->
                        <div class="flex-shrink-0 h-full">
                            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                        </div>

                        <!-- Konten -->
                        <div class="relative flex flex-col flex-1 h-full p-3 md:p-3">

                            <div class="absolute top-0 right-0 mt-2 mr-2">
                                <button id="deleteBtn" class="w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </div>

                            <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                            <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                            <!-- Bagian Harga dan Button -->
                            <div class="flex items-center justify-between gap-4 mt-auto">
                                <div id="orderButtonContainer1" class="absolute bottom-4 right-2 mb-[2px] flex items-center border border-gray-300 rounded-full w-[100px] h-[30px] overflow-hidden">
                                    <button onclick="decreaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-r border-gray-300">−</button>
                                    <span id="quantity" class="w-1/3 text-lg font-semibold text-center">1</span>
                                    <button onclick="increaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-l border-gray-300">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pesanan 4 -->
                    <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[111px] md:h-[125px] relative">
                        <!-- Gambar -->
                        <div class="flex-shrink-0 h-full">
                            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                        </div>

                        <!-- Konten -->
                        <div class="relative flex flex-col flex-1 h-full p-3 md:p-3">

                            <div class="absolute top-0 right-0 mt-2 mr-2">
                                <button id="deleteBtn" class="w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </div>

                            <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                            <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                            <!-- Bagian Harga dan Button -->
                            <div class="flex items-center justify-between gap-4 mt-auto">
                                <div id="orderButtonContainer1" class="absolute bottom-4 right-2 mb-[2px] flex items-center border border-gray-300 rounded-full w-[100px] h-[30px] overflow-hidden">
                                    <button onclick="decreaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-r border-gray-300">−</button>
                                    <span id="quantity" class="w-1/3 text-lg font-semibold text-center">1</span>
                                    <button onclick="increaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-l border-gray-300">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pesanan 4 -->
                    <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[111px] md:h-[125px] relative">
                        <!-- Gambar -->
                        <div class="flex-shrink-0 h-full">
                            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[125px] h-full rounded-2xl object-cover">
                        </div>

                        <!-- Konten -->
                        <div class="relative flex flex-col flex-1 h-full p-3 md:p-3">

                            <div class="absolute top-0 right-0 mt-2 mr-2">
                                <button id="deleteBtn" class="w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                    </svg>
                                </button>
                            </div>

                            <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                            <p class="text-black font-semibold text-[16px] md:text-[18px] mt-1">Rp 15.000</p>
                            <!-- Bagian Harga dan Button -->
                            <div class="flex items-center justify-between gap-4 mt-auto">
                                <div id="orderButtonContainer1" class="absolute bottom-4 right-2 mb-[2px] flex items-center border border-gray-300 rounded-full w-[100px] h-[30px] overflow-hidden">
                                    <button onclick="decreaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-r border-gray-300">−</button>
                                    <span id="quantity" class="w-1/3 text-lg font-semibold text-center">1</span>
                                    <button onclick="increaseQuantity()" class="w-1/3 text-xl text-center text-gray-600 border-l border-gray-300">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="border-t-[2px] border-dashed" style="border-image: repeating-linear-gradient(90deg, #000, #000 15px, transparent 5px, transparent 30px) 1;"></div>

                    <form>
                        <div class="p-4">
                            <textarea class="w-full p-2 border border-black rounded-md h-[155px] mb-[20px]" placeholder="Tambahan lainnya"></textarea>

                            <div class="space-y-4">
                                <!-- Baris 1: Nama Pelanggan -->
                                <div class="flex items-center justify-between">
                                    <label class="text-[15px] font-semibold">Nama Pelanggan :</label>
                                    <input type="text" class="w-[160px] h-[25px] p-2 border border-black rounded-full">
                                </div>

                                <!-- Baris 2: Nomor Meja -->
                                <div class="flex items-center justify-between">
                                    <label class="text-[15px] font-semibold">Nomor Meja :</label>
                                    <input type="number" class="w-[160px] h-[25px] p-2 border border-black rounded-full">
                                </div>

                                <div class="flex items-center justify-between mb-[15px]">
                                    <span class="text-[24px] font-semibold">Total:</span>
                                    <span class="text-[24px] font-semibold mr-[14px]">Rp. 103.000</span>
                                </div>
                            </div>
                        </div>


                        <div class="border-t-[2px] border-dashed" style="border-image: repeating-linear-gradient(90deg, #000, #000 15px, transparent 5px, transparent 30px) 1;"></div>

                        <div class="p-4">
                            <p class="text-[24px] font-semibold mb-[40px]">Metode Pembayaran</p>
                            <div class="flex items-center justify-center mb-[30px] gap-x-[70px]">
                                <button class="w-[107px] h-[90px] bg-[#E5E1DA] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF] hover:border-[#FADA7A] hover:border-[5px]">
                                    <img src="/images/bayar-tunai.png" class="w-[45px] h-[40px]">
                                    <span class="font-medium text-[16px] text-[#EFB036]">Cash</span>
                                </button>
                                <button  class="w-[107px] h-[90px] bg-[#E5E1DA] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF] hover:border-[#FADA7A] hover:border-[5px]">
                                    <img src="/images/bayar-qris.png" class="w-[45px] h-[45px]">
                                    <span class="font-medium text-[16px] text-[#EFB036]">Qris</span>
                                </button>
                            </div>

                            <button  class="w-full h-[40px] bg-[#FADA7A] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF]">
                                <span class="font-semibold text-[15px] text-[#000000]">Proses Pesanan</span>
                            </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

    </div>


    @endsection
