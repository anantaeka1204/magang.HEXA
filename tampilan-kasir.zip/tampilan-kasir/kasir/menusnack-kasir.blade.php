    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center justify-between w-full">
            <!-- Bagian Kiri: Menu & Tambah Menu -->
            <div class="flex items-center space-x-5">
                <span class="text-[24px] font-bold">Menu</span>
                <!-- Button Tambah Menu -->
                <div class="bg-[#ffffff] text-black px-4 py-2 border border-1 rounded-full cursor-pointer hover:bg-[#FADA7A] shadow-md">
                    <a href="/kasir/tambahmenu-kasir">+ Tambah Menu</a>
                </div>
            </div>

            <!-- Search -->
            <div class="search-menu flex items-center px-2 py-2 rounded-3xl shadow-sm w-[226px] border border-1 border-black">
                <input type="text" placeholder="Cari Menu"
                    class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[170px]">
                <!-- Button Search -->
                <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-[20px] h-[20px]">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                </button>
            </div>
        </div>

        <!-- Button Menu Kategori -->
        <hr class="border mt-[20px] border-black/15">

            <div class="pt-[20px] mb-[20px] overflow-x-auto set-scroll whitespace-nowrap">
                <div class="flex space-x-4 flex-nowrap">
                    <a href="/kasir/menusemua-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A]  border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm flex justify-center items-center group transition">
                        <span class="text-[14px] md:text-[16px] font-medium">Semua Menu</span>
                    </a>
                    <a href="/kasir/menumakanan-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/makanan-pelanggan.png" alt="Makanan"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Makanan</span>
                    </a>
                    <a href="/kasir/menuminuman-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/minuman-pelanggan.png" alt="Minuman"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Minuman</span>
                    </a>
                    <a href="/kasir/menusnack-kasir" class="menu-makanan bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <img src="/images/snack-pelanggan.png" alt="Snack"
                                class="w-[25px] h-[25px] object-cover aspect-square">
                        </span>
                        <span class="text-[14px] md:text-[16px] font-medium justify-start">Snack</span>
                    </a>
                </div>
            </div>

        <!-- Menu Makanan -->
        <div class="grid items-center justify-around grid-cols-5">
            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <button data-item-id="1" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                </svg>
                            </button>
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <button data-item-id="2" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                </svg>
                            </button>
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <button data-item-id="3" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                    stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                </svg>
                            </button>
                            <!-- Icons + -->
                            <a href="/kasir/pesanmenu-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- Modal Pop-up -->
        <div id="deleteModal" class="fixed inset-0 items-center justify-center hidden bg-black bg-opacity-50">
            <div class="bg-white w-[447px] h-[172px] p-8 rounded-lg shadow-lg text-center">
                <p class="text-lg font-semibold">Apakah ingin menghapus menu bakso campur?</p>
                <div class="flex justify-center mt-4 space-x-[45px]">
                    <button id="confirmDelete" class="px-4 py-1 text-white bg-red-600 rounded-lg">Hapus</button>
                    <button id="cancelDelete" class="px-4 py-1 bg-gray-300 rounded-lg">Batal</button>
                </div>
            </div>
        </div>


    </div>

    @endsection

    <script>
   document.addEventListener("DOMContentLoaded", function () {
    // Tangkap semua tombol delete dengan class .deleteBtn
    const deleteBtns = document.querySelectorAll(".deleteBtn");

    // Tangkap elemen modal dan tombol konfirmasi/batal
    const deleteModal = document.getElementById("deleteModal");
    const confirmDelete = document.getElementById("confirmDelete");
    const cancelDelete = document.getElementById("cancelDelete");
    const itemIdDisplay = document.getElementById("itemIdDisplay"); // Elemen untuk menampilkan ID item

    // Variabel untuk menyimpan ID item yang akan dihapus
    let itemIdToDelete = null;

    // Loop melalui setiap tombol delete
    deleteBtns.forEach((deleteBtn) => {
        deleteBtn.addEventListener("click", () => {
            // Ambil nilai data-item-id dari tombol yang diklik
            itemIdToDelete = deleteBtn.getAttribute("data-item-id");

            // Tampilkan ID item di modal (opsional)
            if (itemIdDisplay) {
                itemIdDisplay.textContent = itemIdToDelete;
            }

            // Tampilkan modal
            deleteModal.classList.remove("hidden");
            deleteModal.classList.add("flex");
        });
    });

    // Sembunyikan modal saat tombol batal diklik
    cancelDelete.addEventListener("click", () => {
        deleteModal.classList.remove("flex");
        deleteModal.classList.add("hidden");
    });

    // Handle tombol konfirmasi hapus
    confirmDelete.addEventListener("click", () => {
        if (itemIdToDelete) {
            console.log(`Item dengan ID ${itemIdToDelete} akan dihapus`); // Lakukan aksi hapus di sini
            // Contoh: Panggil fungsi atau API untuk menghapus item
            // deleteItem(itemIdToDelete);
        }

        // Sembunyikan modal setelah konfirmasi
        deleteModal.classList.remove("flex");
        deleteModal.classList.add("hidden");
    });
});
    </script>

