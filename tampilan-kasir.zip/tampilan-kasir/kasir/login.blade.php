    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        @layer utilities {
        .no-autofill {
            @apply bg-white;
        }

        input:-webkit-autofill {
            @apply bg-white !important;
            box-shadow: 0 0 0px 1000px white inset !important;
        }
        }

    </style>

<!-- Gradient Bulat -->
<div class="absolute top-[-150px] left-[-100px] w-[400px] h-[406px] rounded-full bg-[radial-gradient(circle,#EFB03666_0%,#FFFFFF_100%)] blur-xl z-[-1]"></div>
<div class="absolute top-[-20px] right-[-200px] w-[536px] h-[536px] rounded-full bg-[radial-gradient(circle,#EFB03666_0%,#FFFFFF_100%)] blur-xl z-[-1]"></div>
<div class="absolute bottom-[-250px] left-[-5px] w-[536px] h-[536px] rounded-full bg-[radial-gradient(circle,#FADA7A8C_0%,#FFFFFF_100%)] blur-xl z-[-1]"></div>

<!-- Header -->
<div class="header flex justify-between items-center text-black p-4 h-[50px] md:p-6 md:h-[95px]">
    <h1 class="text-[24px] font-semibold">TapEats</h1>
</div>

<!-- Login -->
<form action="">
<div class="flex flex-col items-center justify-center">
    <div class="mt-[40px]">
        <h1 class="text-[20px] font-medium text-center">Selamat Datang di TapEats!</h1>
    </div>

<div class="w-96 mt-[90px]">
        <label class="block mb-1 font-medium text-[16px]">Email</label>
<div class="flex items-center w-full p-1 py-3 bg-white border-2 rounded-md">
    <input type="text" placeholder="example@gmail.com"
        class="w-full bg-transparent outline-none pl-4 placeholder-gray-400 text-[12px]" autocomplete="new-email">
</div>

<label class="block mt-4 mb-1 font-medium text-[16px]">Password</label>
<div class="relative">
    <div class="flex items-center w-full p-1 py-3 bg-white border-2 rounded-md">
        <input type="password" id="passwordInput" placeholder="Masukkan password"
            class="w-full bg-transparent outline-none pl-4 placeholder-gray-400 text-[12px]" autocomplete="new-password">
        <span class="mr-3 cursor-pointer" id="togglePassword">
            <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
            </svg>
        </span>
    </div>
</div>

        <button class="w-full py-2 mt-[90px] font-medium text-black transition bg-[#EFB036] rounded-md hover:bg-yellow-600">
            Login
        </button>
    </div>

</div>

</div>
</form>


<script>
    document.getElementById("togglePassword").addEventListener("click", function () {
        const passwordInput = document.getElementById("passwordInput");
        const eyeIcon = document.getElementById("eyeIcon");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
            eyeIcon.setAttribute("fill", "none");
        }
    });
</script>

