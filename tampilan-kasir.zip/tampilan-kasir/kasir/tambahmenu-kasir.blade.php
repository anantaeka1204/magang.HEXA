    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center justify-between w-full">
            <!-- Bagian Kiri: Menu & Tambah Menu -->
            <div class="flex items-center space-x-5">
                <span class="text-[24px] font-bold">Menu</span>
                <!-- Button Tambah Menu -->
                <div class="bg-[#FADA7A] px-4 py-2 text-black border rounded-full shadow-md cursor-pointer border-1">
                    <a>+ Tambah Menu</a>
                </div>
            </div>

            <!-- Search -->
            <div class="search-menu flex items-center px-2 py-2 rounded-3xl shadow-sm w-[226px] border border-1 border-black">
                <input type="text" placeholder="Cari Menu"
                    class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[170px]">
                <!-- Button Search -->
                <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-[20px] h-[20px]">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                </button>
            </div>
        </div>

        <!-- Button Menu Kategori -->
        <hr class="border mt-[20px] border-black/15">

        <!-- Input Menu -->
        <div class="w-full mt-[40px]">
            <form>
                <div class="grid grid-cols-2 gap-x-[50px] gap-y-[40px] items-center justify-center">
                    <!-- Nama Menu -->
                    <div>
                        <label class="block mb-1 text-[16px] font-normal">Nama Menu :</label>
                        <input type="text" class="w-full p-2 border border-black rounded-lg focus:ring-2 ">
                    </div>

                    <!-- Harga -->
                    <div>
                        <label class="block mb-1 text-[16px] font-normal">Harga :</label>
                        <input type="number" class="w-full p-2 border border-black rounded-lg focus:ring-2 ">
                    </div>

                    <!-- Kolom Kiri -->
                    <div>
                        <label class="block mb-2 text-[16px] font-normal">Deskripsi Menu :</label>
                        <textarea class="w-full p-2 border border-black rounded-md h-[155px]"></textarea>
                    </div>

                    <!-- Kolom Kanan -->
                    <div>
                        <div class="mb-[20px]">
                            <label class="block mb-2 text-[16px] font-normal">Kategori :</label>
                            <select class="w-full p-2 bg-white border border-black rounded-md">
                                <option></option>
                                <option>Makanan</option>
                                <option>Minuman</option>
                                <option>Snack</option>
                            </select>
                        </div>

                        <div>
                            <!-- Label "File Gambar Menu" -->
                            <label class="block text-[16px] font-normal">File Gambar Menu :</label>

                            <!-- Container untuk Input dan Gambar -->
                            <div class="flex items-center gap-4">
                                <!-- Input File -->
                                <label for="gambarmenu" class="flex items-center p-2 border border-black rounded-lg text-[#686D76] text-[16px] font-light cursor-pointer w-[500px]">
                                    <img src="/images/fileupload.png" class="w-[22px] h-[24px]">
                                    <span class="ml-2">Pilih file</span>
                                </label>
                                <input type="file" id="gambarmenu" accept="image/*" class="hidden">

                                <!-- Gambar yang Ditampilkan (Kondisional) -->
                                <img id="previewImage" src="/images/bakso campur.jpg" alt="Preview Gambar" class="w-[100px] h-[100px] object-cover rounded-lg">
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Tombol -->
                <div class="flex justify-between gap-x-[50px] mt-[70px]">
                    <button id="button" type="reset"
                       class="w-full py-3 text-[16px] font-semibold text-white bg-[#BB1717] rounded-full shadow-lg hover:bg-[#bb17179d] flex items-center justify-center">
                        Batal
                    </button>
                    <button id="button" type="submit"
                       class="w-full py-3 text-[16px] font-semibold text-black bg-[#FADA7A] rounded-full shadow-lg hover:bg-[#fada7a85] flex items-center justify-center">
                        Tambah
                    </button>
                </div>
            </form>
        </div>


    </div>

    @endsection
