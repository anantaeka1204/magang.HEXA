    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

    <p class="font-bold text-[24px] pt-[10px] pb-[20px]">Riwayat Pesanan</p>

    <div class="search-menu flex items-center px-2 py-2 rounded-sm shadow-sm w-[300px] border border-1 border-[#E2E8F0]">
        <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
            <!-- Icons Search -->
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#808080" class="w-[20px] h-[20px]">
                <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
            </svg>
        </button>
        <input type="text" placeholder="Cari Menu"
            class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[280px]">
    </div>

    <div class="pt-[40px]"></div>

    <!-- Tabel Riwayat Pesanan -->
    <div class="overflow-x-auto rounded-xl border border-[#E5E1DA]">
        <div class="overflow-hidden rounded-lg">
            <table class="min-w-full bg-white border-separate border-spacing-0">
                <thead>
                    <tr class="bg-white">
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">#</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Nama Pelanggan</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">No Meja</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Tanggal</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Pembayaran</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Menu</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Status Pesanan</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA] text-[14px] text-[#62748E] text-left">Status Pembayaran</th>
                        <th class="py-2 px-4 border-b border-[#E5E1DA]  text-[14px] text-[#62748E] text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="bg-white">
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-semibold text-black bg-[#FFA500] rounded-full">
                                Menunggu
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#BB1717] rounded-full">
                                Belum Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <a href="/kasir/detailpesanan-kasir" class="py-[5px] px-[10px] bg-[#22b14d] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#CA2A2A] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-white">
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-semibold text-white bg-[#0000FF] rounded-full">
                                Dikonfirmasi
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-black bg-[#B8D576] rounded-full">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <a href="/kasir/detailpesanan-kasir" class="py-[5px] px-[10px] bg-[#22b14d] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#CA2A2A] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-white">
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-semibold text-black bg-[#FADA7A] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-black bg-[#B8D576] rounded-full">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <a href="/kasir/detailpesanan-kasir" class="py-[5px] px-[10px] bg-[#22b14d] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#CA2A2A] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-white">
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-semibold text-black bg-[#B8D576] rounded-full">
                                Selesai
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-black bg-[#B8D576] rounded-full">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border-b border-[#E5E1DA]">
                            <a href="/kasir/detailpesanan-kasir" class="py-[5px] px-[10px] bg-[#22b14d] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#CA2A2A] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>


                </tbody>
            </table>
        </div>
    </div>


    <div>

    @endsection
