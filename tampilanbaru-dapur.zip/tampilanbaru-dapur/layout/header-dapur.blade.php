<header id="header-dapur" class="flex items-center justify-between md:px-[30px] lg:px-[50px] xl:px-[50px]  bg-white h-[90px] border-b-2 border-[#E5E1DA]">
    <!-- Tap Eats -->
    <h1 class="font-bold text-black md:text-[32px] lg:text-[32px] xl:text-[32px]">TapEats</h1>

    <!-- Bagian Menu dan Riwayat Pesanan -->
    <div class="flex gap-[20px] mr-auto md:ml-[30px] lg:ml-[40px] xl:ml-[40px]">
        <!-- Menu -->
        <a href="/dapur/" data-page="dapur-menu" class="dapur-header flex items-center justify-center gap-[11px] h-[67px] md:w-[100px] lg:w-[171px] xl:w-[171px] text-black hover:bg-[#FADA7A] rounded-[10px]">
            <!-- Icons Menu -->
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                <path d="M3.75 2.5H6.25V27.5H3.75V2.5ZM12.5 7.5H21.25V10H12.5V7.5ZM12.5 12.5H21.25V15H12.5V12.5Z" fill="black"/>
                <path d="M23.75 2.5H7.5V27.5H23.75C25.1287 27.5 26.25 26.3787 26.25 25V5C26.25 3.62125 25.1287 2.5 23.75 2.5ZM23.75 25H10V5H23.75V25Z" fill="black"/>
            </svg>
            <!-- Tulisan Menu -->
            <span class="text-[16px] font-medium">Menu</span>
        </a>

        <!-- Riwayat Pesanan -->
        <a href="/dapur/riwayatpesananall-dapur" data-page="dapur-riwayatpesanan" class="dapur-header flex items-center justify-center gap-[11px] h-[67px] md:w-[190px] lg:w-[227px] xl:w-[227px] text-black hover:bg-[#FADA7A] rounded-[10px]">
            <!-- Icons Riwayat Pesanan -->
            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35" fill="none">
                <path d="M17.5003 9.47917V17.9273L11.8799 23.5463C11.7429 23.6832 11.666 23.8689 11.666 24.0625C11.666 24.2561 11.7429 24.4418 11.8799 24.5788C12.0168 24.7157 12.2025 24.7926 12.3961 24.7926C12.5897 24.7926 12.7754 24.7157 12.9124 24.5788L18.7457 18.7454C18.8134 18.6776 18.867 18.5971 18.9035 18.5085C18.9401 18.4199 18.9588 18.325 18.9586 18.2292V9.47917C18.9586 9.28578 18.8818 9.10031 18.745 8.96357C18.6083 8.82682 18.4228 8.75 18.2294 8.75C18.036 8.75 17.8506 8.82682 17.7138 8.96357C17.5771 9.10031 17.5003 9.28578 17.5003 9.47917ZM29.8961 23.3333H21.1461C20.9527 23.3333 20.7672 23.4102 20.6305 23.5469C20.4938 23.6836 20.4169 23.8691 20.4169 24.0625C20.4169 24.2559 20.4938 24.4414 20.6305 24.5781C20.7672 24.7148 20.9527 24.7917 21.1461 24.7917H29.8961C30.0895 24.7917 30.275 24.7148 30.4117 24.5781C30.5484 24.4414 30.6253 24.2559 30.6253 24.0625C30.6253 23.8691 30.5484 23.6836 30.4117 23.5469C30.275 23.4102 30.0895 23.3333 29.8961 23.3333Z" fill="black"/>
                <path d="M28.4379 8.75069C28.2445 8.75069 28.059 8.82751 27.9223 8.96425C27.7855 9.101 27.7087 9.28647 27.7087 9.47985V10.279C26.5545 8.88466 25.106 7.76301 23.4671 6.99451C21.8283 6.226 20.0396 5.8297 18.2296 5.83402C16.191 5.83406 14.184 6.33686 12.3862 7.29786C10.5884 8.25887 9.05532 9.64842 7.92283 11.3434C6.79034 13.0385 6.09336 14.9866 5.89363 17.0153C5.6939 19.0441 5.99758 21.0907 6.77778 22.974C7.55797 24.8574 8.7906 26.5192 10.3665 27.8124C11.9423 29.1055 13.8128 29.9901 15.8122 30.3876C17.8116 30.7852 19.8782 30.6836 21.8289 30.0917C23.7796 29.4998 25.5542 28.436 26.9956 26.9944C27.1329 26.8569 27.21 26.6705 27.2098 26.4762C27.2097 26.2819 27.1324 26.0956 26.9949 25.9583C26.8574 25.821 26.671 25.7439 26.4766 25.7441C26.2823 25.7442 26.096 25.8215 25.9587 25.959C24.3837 27.5372 22.3639 28.5963 20.17 28.9944C17.9762 29.3925 15.7131 29.1107 13.6839 28.1865C11.6548 27.2624 9.95652 25.7402 8.81671 23.8239C7.67691 21.9076 7.15001 19.6887 7.30661 17.4645C7.46321 15.2403 8.29583 13.1171 9.6929 11.3794C11.09 9.64173 12.9848 8.37251 15.1234 7.74184C17.262 7.11117 19.5423 7.14918 21.6587 7.85078C23.7751 8.55238 25.6266 9.88405 26.965 11.6674H25.5212C25.3278 11.6674 25.1424 11.7442 25.0056 11.8809C24.8689 12.0177 24.7921 12.2031 24.7921 12.3965C24.7921 12.5899 24.8689 12.7754 25.0056 12.9121C25.1424 13.0489 25.3278 13.1257 25.5212 13.1257H28.4379C28.6313 13.1257 28.8167 13.0489 28.9535 12.9121C29.0902 12.7754 29.1671 12.5899 29.1671 12.3965V9.47985C29.1671 9.28647 29.0902 9.101 28.9535 8.96425C28.8167 8.82751 28.6313 8.75069 28.4379 8.75069Z" fill="black"/>
                <path d="M25.5213 14.584C25.3279 14.584 25.1424 14.6608 25.0057 14.7976C24.8689 14.9343 24.7921 15.1198 24.7921 15.3132V16.1065C23.7534 16.257 22.7861 16.7234 22.0215 17.4424C21.2569 18.1614 20.7319 19.0982 20.5177 20.1257C20.4744 20.3378 20.4789 20.5569 20.5309 20.7671C20.5828 20.9773 20.6809 21.1733 20.818 21.3409C20.9551 21.5085 21.1279 21.6434 21.3236 21.7359C21.5194 21.8284 21.7333 21.8761 21.9498 21.8757H29.0957C29.3122 21.8761 29.5261 21.8284 29.7219 21.7359C29.9176 21.6434 30.0904 21.5085 30.2275 21.3409C30.3646 21.1733 30.4627 20.9773 30.5146 20.7671C30.5666 20.5569 30.5711 20.3378 30.5277 20.1257C30.3134 19.0977 29.788 18.1607 29.0228 17.4417C28.2576 16.7226 27.2897 16.2565 26.2505 16.1065V15.3132C26.2505 15.1198 26.1736 14.9343 26.0369 14.7976C25.9001 14.6608 25.7147 14.584 25.5213 14.584Z" fill="black"/>
            </svg>
            <!-- Tulisan Riwayat Pesanan -->
            <span class="text-[16px] font-medium">Riwayat Pesanan</span>
        </a>
    </div>

    <!-- Bagian Logout dan Profil -->
    <div class="flex items-center ml-auto gap-[30px]">
        <!-- Logout -->
        <a href="" class="p-[10px] bg-[#FFFFFF] hover:bg-[#fff9f9] rounded-[5px] text-[#CA2A2A] inline-flex items-center gap-[11px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]">
            <!-- Icons Logout -->
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M7.5 17.5H4.16667C3.72464 17.5 3.30072 17.3244 2.98816 17.0118C2.6756 16.6993 2.5 16.2754 2.5 15.8333V4.16667C2.5 3.72464 2.6756 3.30072 2.98816 2.98816C3.30072 2.6756 3.72464 2.5 4.16667 2.5H7.5" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11.667 5.83268L7.50033 9.99935L11.667 14.166" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M7.5 10H17.5" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span class="font-medium text-[16px]">Logout</span>
        </a>
        <!-- Profil -->
        <img src="/images/profil.jpg" alt="Profil" class="object-cover w-[50px] h-[46px] rounded-[20px]">
    </div>

</header>

<script>
// Menyimpan Halaman Menu dan Riwayat Header Yang di Kunjungi
document.addEventListener("DOMContentLoaded", function () {
const sidebarItems = document.querySelectorAll(".dapur-header");
let activePage = localStorage.getItem("activeDapur");

if (activePage) {
    sidebarItems.forEach(item => {
        item.classList.remove("bg-[#FADA7A]");
        if (item.getAttribute("href") === activePage) {
            item.classList.add("bg-[#FADA7A]");
        }
    });
}

sidebarItems.forEach(item => {
    item.addEventListener("click", function (event) {
        localStorage.setItem("activeDapur", this.getAttribute("href"));

        sidebarItems.forEach(i => i.classList.remove("bg-[#FADA7A]"));
        this.classList.add("bg-[#FADA7A]");
    });
});
});
</script>



