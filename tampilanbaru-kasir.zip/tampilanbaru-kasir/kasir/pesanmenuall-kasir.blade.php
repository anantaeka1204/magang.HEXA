    @extends('layout.master-kasir')

    @section('tittle-kasir', 'Menu Pesanan Kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center justify-between w-full">
            <!-- Menu & Tambah Menu -->
            <div class="flex items-center gap-[50px]">
                <span class="text-[32px] font-bold">Menu</span>
                <!-- Button Tambah Menu -->
                <div class="bg-[#ffffff] text-black px-[40px] py-2 border border-1 border-[rgba(0,0,0,0.08)] rounded-[15px] cursor-pointer hover:bg-[#FADA7A] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)]">
                    <a href="/kasir/tambahmenu-kasir" class="flex items-center gap-2 text-[16px] font-normal">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path d="M11.002 19.5V13.5H5.00195V11.5H11.002V5.5H13.002V11.5H19.002V13.5H13.002V19.5H11.002Z" fill="black"/>
                      </svg>
                      Tambah Menu
                    </a>
                </div>
            </div>

            <!-- Search -->
            <div class="search-menu flex items-center px-2 py-2 rounded-[16px] shadow-sm w-[226px] border border-1 border-black">
                <input type="text" placeholder="Cari Menu"
                    class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[180px]">
                <!-- Button Search -->
                <button class="flex items-center justify-center rounded-full icon-search">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                        <path d="M21.4172 19.2078L17.4508 15.2414C18.2703 14.0062 18.75 12.5273 18.75 10.9375C18.75 6.62969 15.2453 3.125 10.9375 3.125C6.62969 3.125 3.125 6.62969 3.125 10.9375C3.125 15.2453 6.62969 18.75 10.9375 18.75C12.5273 18.75 14.0062 18.2703 15.2414 17.4508L19.2078 21.4172C19.8172 22.0273 20.8078 22.0273 21.4172 21.4172C22.0273 20.807 22.0273 19.818 21.4172 19.2078ZM5.46875 10.9375C5.46875 7.92187 7.92187 5.46875 10.9375 5.46875C13.9531 5.46875 16.4062 7.92187 16.4062 10.9375C16.4062 13.9531 13.9531 16.4062 10.9375 16.4062C7.92187 16.4062 5.46875 13.9531 5.46875 10.9375Z" fill="black" fill-opacity="0.4"/>
                    </svg>
                </button>
            </div>
        </div>

        <!-- Garis -->
        <hr class="border mt-[20px] border-black/15">

            <!-- Button Menu Kategori -->
            <div class="pt-[20px] pb-[10px] overflow-x-auto set-scroll">
                <div class="flex gap-[10px]">
                    <a href="/kasir/pesanmenuall-kasir" class="semua-menu bg-[#FADA7A] border border-1 h-[45px] w-[175px] rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                        <span class="text-[16px] font-medium">Semua Menu</span>
                    </a>
                    <a href="/kasir/pesanmenumakanan-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                <path d="M5.32812 16.0742V19.0695C6.2433 20.1914 7.39682 21.0953 8.70492 21.7157C10.013 22.3361 11.4429 22.6574 12.8906 22.6563C16.2688 22.6563 19.2469 20.9406 21 18.3336V14.1352C20.4 18.075 16.9977 21.0938 12.8906 21.0938C9.48906 21.0938 6.57109 19.0234 5.32812 16.0742ZM19.5547 8.10626V6.76095C19.5521 6.46422 19.6007 6.16926 19.6984 5.88907C17.8774 4.11379 15.4338 3.12168 12.8906 3.12501C10.6147 3.12163 8.40971 3.91645 6.65937 5.3711L6.66328 5.41876L6.66406 5.43985V7.54923C7.43357 6.65072 8.38865 5.92963 9.46355 5.43561C10.5384 4.94159 11.7076 4.68636 12.8906 4.68751C15.6359 4.68751 18.0656 6.03595 19.5547 8.10626Z" fill="black"/>
                                <path d="M19.1406 12.8908C19.1406 14.5484 18.4821 16.1381 17.31 17.3102C16.1379 18.4823 14.5482 19.1408 12.8906 19.1408C11.233 19.1408 9.64331 18.4823 8.47121 17.3102C7.29911 16.1381 6.64062 14.5484 6.64062 12.8908C6.64062 11.2332 7.29911 9.64349 8.47121 8.47139C9.64331 7.29929 11.233 6.64081 12.8906 6.64081C14.5482 6.64081 16.1379 7.29929 17.31 8.47139C18.4821 9.64349 19.1406 11.2332 19.1406 12.8908ZM12.8906 18.3596C13.6088 18.3596 14.3199 18.2181 14.9834 17.9433C15.6469 17.6684 16.2498 17.2656 16.7576 16.7578C17.2654 16.25 17.6683 15.6471 17.9431 14.9836C18.2179 14.3201 18.3594 13.609 18.3594 12.8908C18.3594 12.1726 18.2179 11.4615 17.9431 10.798C17.6683 10.1345 17.2654 9.53164 16.7576 9.02382C16.2498 8.516 15.6469 8.11317 14.9834 7.83834C14.3199 7.56351 13.6088 7.42206 12.8906 7.42206C11.4402 7.42206 10.0492 7.99823 9.02363 9.02382C7.99805 10.0494 7.42188 11.4404 7.42188 12.8908C7.42188 14.3412 7.99805 15.7322 9.02363 16.7578C10.0492 17.7834 11.4402 18.3596 12.8906 18.3596ZM23.4297 6.20331C23.4297 5.50018 22.8594 4.92987 22.1562 4.92987C21.1406 4.92987 20.3281 5.75018 20.3359 6.758V11.0939C20.3359 12.0728 20.9031 12.9494 21.7812 13.3463V20.0783C21.7812 20.4846 22.1094 20.8127 22.5156 20.8127H22.6953C23.1016 20.8127 23.4297 20.4846 23.4297 20.0783V6.20331ZM5.32813 4.92987C5.18723 4.92987 5.0521 4.98584 4.95247 5.08547C4.85285 5.1851 4.79688 5.32022 4.79688 5.46112V7.56268C4.79688 7.71893 4.67188 7.83612 4.52344 7.83612C4.36719 7.83612 4.25 7.71112 4.25 7.56268V5.48456C4.25 5.1955 4.02344 4.93768 3.73438 4.92987C3.42969 4.92206 3.17969 5.16425 3.17969 5.46112V7.56268C3.17969 7.71893 3.05469 7.83612 2.90625 7.83612C2.75 7.83612 2.63281 7.71112 2.63281 7.56268V5.48456C2.63281 5.1955 2.40625 4.93768 2.11719 4.92987C1.8125 4.92206 1.5625 5.16425 1.5625 5.46112V9.03925C1.5625 9.74393 1.90391 10.3728 2.42891 10.765C2.89844 11.0299 2.89844 12.2424 2.89844 12.2424V20.0705C2.89844 20.4767 3.22656 20.8049 3.63281 20.8049H3.8125C4.21875 20.8049 4.54688 20.4767 4.54688 20.0705V12.2424C4.54688 12.2424 4.54688 11.0775 5.01641 10.765C5.28503 10.5645 5.5032 10.3041 5.6536 10.0045C5.804 9.70497 5.88248 9.37446 5.88281 9.03925V5.46112C5.8749 5.31876 5.81322 5.18471 5.71025 5.08609C5.60728 4.98747 5.4707 4.93163 5.32813 4.92987Z" fill="black"/>
                            </svg>
                        </span>
                        <span class="text-[16px] font-medium justify-start">Makanan</span>
                    </a>
                    <a href="/kasir/pesanmenuminuman-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] 5px] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                <path d="M15.0835 1.04199H20.8335V3.12533H16.646L15.9689 5.43991H20.9064L19.6439 23.9587H6.4762L5.56995 10.7066C3.61995 10.2743 2.0835 8.58262 2.0835 6.48158C2.0835 4.06491 4.07725 2.14199 6.49079 2.14199C8.546 2.14199 10.296 3.5347 10.772 5.43991H13.797L15.0835 1.04199ZM13.1877 7.52324H7.44287L7.6887 11.1503L11.9252 11.8389L13.1877 7.52324ZM12.496 14.042L7.83454 13.2847L8.42204 21.8753H17.697L18.1668 14.9837L12.5002 14.043L12.496 14.042ZM18.3095 12.8962L18.6762 7.52324H15.3585L13.996 12.1795L18.3095 12.8962ZM8.55329 5.43887C8.35212 5.06828 8.05386 4.75945 7.69052 4.54548C7.32717 4.33151 6.91244 4.22047 6.49079 4.22428C5.18766 4.22533 4.16683 5.25553 4.16683 6.48158C4.16683 7.31178 4.66683 8.06803 5.41787 8.45658L5.21266 5.43991L8.55329 5.43887Z" fill="black"/>
                            </svg>
                        </span>
                        <span class="text-[16px] font-medium justify-start">Minuman</span>
                    </a>
                    <a href="/kasir/pesanmenusnack-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                        <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                <path d="M16.9937 4.11416C16.7926 3.54516 16.4272 3.04862 15.9437 2.68743C15.4603 2.32625 14.8805 2.11666 14.2778 2.0852C13.6752 2.05375 13.0767 2.20184 12.5583 2.51074C12.0399 2.81963 11.6248 3.27543 11.3655 3.82041C11.0426 4.49749 10.2312 5.11416 9.48325 5.18291C8.67402 5.25663 7.91441 5.60519 7.33079 6.17059C6.74718 6.736 6.37472 7.48417 6.27539 8.29066C6.17605 9.09715 6.35582 9.91335 6.7848 10.6035C7.21377 11.2936 7.86609 11.8161 8.63325 12.0839M8.63325 12.0839C8.30855 12.342 8.03991 12.6636 7.84378 13.0291C7.64765 13.3945 7.52814 13.7962 7.49258 14.2094C7.45701 14.6226 7.50613 15.0388 7.63693 15.4324C7.76774 15.826 7.97747 16.1888 8.2533 16.4985C8.52913 16.8083 8.86526 17.0585 9.24113 17.2339C9.61699 17.4092 10.0247 17.5061 10.4393 17.5185C10.8538 17.5308 11.2666 17.4585 11.6522 17.3059C12.0379 17.1533 12.3884 16.9236 12.6822 16.6308C12.7083 16.6058 12.7399 16.5872 12.7745 16.5765C12.8091 16.5659 12.8456 16.5635 12.8813 16.5696C12.917 16.5757 12.9507 16.59 12.9798 16.6115C13.0089 16.633 13.0326 16.661 13.0489 16.6933C13.4333 17.537 14.1319 18.1972 14.9958 18.5335C15.8598 18.8697 16.8209 18.8553 17.6745 18.4935C18.528 18.1316 19.2066 17.4508 19.5657 16.596C19.9247 15.7413 19.9359 14.7801 19.5968 13.9173M8.63325 12.0839C9.21938 11.62 9.95553 11.3875 10.7018 11.4307C11.4481 11.474 12.1525 11.7898 12.6812 12.3183M16.2749 7.28812C16.6821 6.88067 16.9657 6.36629 17.0929 5.80444C17.2201 5.2426 17.1857 4.65623 16.9937 4.11312C17.1467 3.68213 17.3947 3.29109 17.7193 2.96895C18.0439 2.64682 18.4369 2.40184 18.869 2.25216C19.3012 2.10248 19.7615 2.05193 20.2158 2.10426C20.6702 2.1566 21.1069 2.31047 21.4937 2.55448C21.8805 2.7985 22.2075 3.1264 22.4503 3.51391C22.6932 3.90142 22.8458 4.33861 22.8969 4.79309C22.9479 5.24758 22.896 5.70772 22.7451 6.13943C22.5941 6.57115 22.348 6.96338 22.0249 7.28707C21.7041 7.60791 21.7041 8.40478 22.0239 8.72457C22.4666 9.16735 22.7623 9.7357 22.8707 10.3524C22.9791 10.9691 22.8951 11.6042 22.63 12.1714C22.3648 12.7387 21.9315 13.2105 21.3888 13.5229C20.8461 13.8352 20.2205 13.9729 19.5968 13.9173M19.5968 13.9173C19.0694 13.8702 18.5633 13.6867 18.1283 13.3848C17.6932 13.0829 17.3442 12.673 17.1155 12.1954M2.08325 22.9162L8.33325 16.6662" stroke="black" stroke-width="1.5625" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        <span class="text-[16px] font-medium justify-start">Snack</span>
                    </a>
                </div>
            </div>



<div class="flex flex-row w-full gap-4 p-4">

    <!-- Kolom Menu Makanan -->
    <div class="w-[50%] md:w-[50%] lg:w-[50%] xl:w-[60%]">
        <div class="h-auto">

            <p class="font-semibold text-[20px] pb-[20px]">Makanan</p>

            <!-- Menu Makanan -->
            <div class="grid items-center justify-around gap-[1px] xl:gap-[5px] grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">

            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Isi: Pentol, tahu, gorengan</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/mie ayam.jpg" alt="Mie Ayam" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Mie Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Mie dengan topping potongan ayam berbumbu kecap</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/kare ayam.jpg" alt="Kari Ayam" class="object-cover w-[239px] h-[202px] saturate-0">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Kari Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Olahan ayam dengan kuah santan dan bumbu rempah khas</p>
                    <p class="text-[14px] text-[#CA2A2A] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok Habis</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/rawon.jpg" alt="Rawon" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Rawon</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup kuah hitam dengan topping potongan daging sapi empuk</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 22.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 5 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/soto ayam.jpg" alt="Soto Ayam" class="object-cover w-[239px] h-[202px] saturate-0">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Soto Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup dengan topping potongan ayam suwir dan bihun</p>
                    <p class="text-[14px] text-[#CA2A2A] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok Habis</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 12.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 6 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/sup daging.jpg" alt="Sup Daging" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Sup Daging</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup dengan topping potongan daging dan sayuran segar</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 20.000</p>
                        <!-- Icons Sampah dan + -->
                        <div class="flex space-x-3">
                            <!-- Icons + -->
                            <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                    class="w-[20px] h-[20px] object-cover">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Minuman -->
    <p class="font-semibold text-[20px] pb-[20px]">Minuman</p>

    <!-- Menu Minuman -->
    <div class="grid items-center justify-around gap-[1px] xl:gap-[5px] grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">

    <!-- Card 1 -->
    <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/air mineral.jpg" alt="Air Mineral" class="object-cover w-[239px] h-[202px]">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Air Mineral</h2>
            <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 3.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2 -->
    <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/es teh.jpg" alt="Es Teh" class="object-cover w-[239px] h-[202px]">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Es Teh</h2>
            <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 3.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3 -->
    <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/teh hangat.jpg" alt="Teh Panas" class="object-cover w-[239px] h-[202px]">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Teh Panas</h2>
            <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 2.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

   <!-- Card 4 -->
   <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/es jeruk.jpg" alt="Es Jeruk" class="object-cover w-[239px] h-[202px]">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Es Jeruk</h2>
            <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 4.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 5 -->
    <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/jeruk hangat.jpg" alt="Jeruk Panas" class="object-cover w-[239px] h-[202px]">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Jeruk Panas</h2>
            <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 4.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 6 -->
    <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[20px] flex flex-col">
        <!-- Gambar -->
        <img src="/images/jus jambu.jpg" alt="Jus Jambu" class="object-cover w-[239px] h-[202px] saturate-0">

        <!-- Konten Teks -->
        <div class="flex flex-col flex-grow p-4 pt-1">
            <h2 class="text-[20px] font-bold">Jus Jambu</h2>
            <p class="text-[14px] text-[#CA2A2A] font-medium mt-[10px]">Stok Habis</p>

            <!-- Harga dan Tombol -->
            <div class="flex items-center justify-between mt-auto">
                <p class="font-semibold text-[18px]">Rp. 8.000</p>
                <!-- Icons Sampah dan + -->
                <div class="flex space-x-3">
                    <!-- Icons + -->
                    <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="w-[20px] h-[20px] object-cover">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
    </div>


    <!-- Snack -->
    <p class="font-semibold text-[20px] pb-[20px]">Snack</p>

    <!-- Menu Snack -->
    <div class="grid items-center justify-around gap-[1px] xl:gap-[5px] grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">

        <!-- Card 1 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/keripik pisang.jpg" alt="Keripik Pisang" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Keripik Pisang</h2>
                <p class="text-[13px] font-light text-[#686D76]">Irisan pisang pilihan yang digoreng hingga renyah</p>
                <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 10.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <!-- Icons + -->
                        <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/usus goreng.jpg" alt="Keripik Usus" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Keripik Usus</h2>
                <p class="text-[13px] font-light text-[#686D76]">Usus ayam crispy dengan bumbu gurih</p>
                <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 7.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <!-- Icons + -->
                        <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/keripik balado.jpg" alt="Keripik Balado" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Keripik Balado</h2>
                <p class="text-[13px] font-light text-[#686D76]">Keripik singkong renyah dengan bumbu balado</p>
                <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 8.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <!-- Icons + -->
                        <a href="" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>


    <!-- Kolom Pesanan -->
    <div class="w-[50%] md:w-[50%] lg:w-[50%] xl:w-[40%] pt-[50px]">
        <div class="relative bg-[#E5E1DA] p-4 rounded-t-[5px] flex items-center justify-center">
            <h2 class="text-[20px] font-semibold">Pesanan Kamu</h2>
            <button class="absolute text-lg text-black top-4 right-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M18 6L6 18" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M6 6L18 18" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>

        <!-- Pesanan -->
        <div class="h-auto p-4 overflow-y-auto border-[#E5E1DA] border-[2px]">
            <div class="space-y-[25px]">
                <div class="h-[500px] overflow-y-auto">
                <div class="grid items-center justify-center grid-cols-1 gap-y-[15px] p-2 pt-[30px]">

                    <!--Keranjang Kosong -->
                    <div class="flex flex-col items-center justify-center">
                        <img src="/images/pesanan kosong.jpg" alt="pesanan kosong" class="w-[286px] h-[286px]">
                        <p class="text-[16px] font-normal text-[#686D76]">Buat Pesanan</p>
                    </div>

                </div>
                </div>

                <!-- Garis Putus -->
                <div class="border-t-[2px] border-dashed" style="border-image: repeating-linear-gradient(90deg, #000, #000 15px, transparent 5px, transparent 30px) 1;"></div>

                <!-- Bagian Bawah -->
                    <form>
                        <div class="p-4">
                            <textarea class="w-full p-2 border border-black rounded-md h-[155px] mb-[20px]" placeholder="Tambahan lainnya"></textarea>

                            <div class="space-y-4">
                                <!-- Nama Pelanggan -->
                                <div class="flex items-center justify-between">
                                    <label class="text-[15px] font-semibold">Nama Pelanggan :</label>
                                    <input type="text" class="w-[160px] h-[25px] p-2 border border-black rounded-[16px]">
                                </div>

                                <!-- Nomor Meja -->
                                <div class="flex items-center justify-between">
                                    <label class="text-[15px] font-semibold">Nomor Meja :</label>
                                    <input type="number" class="w-[160px] h-[25px] p-2 border border-black rounded-[16px]">
                                </div>

                                <!-- Total Harga -->
                                <div class="flex items-center justify-between mb-[15px]">
                                    <span class="text-[24px] font-semibold">Total:</span>
                                    <span class="text-[24px] font-semibold mr-[14px]">Rp. 103.000</span>
                                </div>
                            </div>
                        </div>

                        <!-- Garis Putus -->
                        <div class="border-t-[2px] border-dashed" style="border-image: repeating-linear-gradient(90deg, #000, #000 15px, transparent 5px, transparent 30px) 1;"></div>

                        <!-- Pilih Metode Pembayaran -->
                        <div class="p-4">
                            <p class="text-[24px] font-semibold mb-[40px]">Metode Pembayaran</p>
                            <div class="flex items-center justify-center mb-[30px] gap-x-[70px]">
                                <button type="button" id="button-pay" class="button-pay w-[107px] h-[90px] bg-[#E5E1DA] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF] hover:border-[#FADA7A] hover:border-[5px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="43" height="33" viewBox="0 0 43 33" fill="none">
                                        <path d="M18.4761 18.5391H16.437C16.0151 18.5391 15.5933 18.1875 15.5933 17.7656C15.5933 17.3438 15.9448 16.9922 16.437 16.9922H20.8667C21.7104 16.9922 22.4136 16.2891 22.4136 15.4453C22.4136 14.6016 21.7104 13.8984 20.8667 13.8984H19.7417V13.4766C19.7417 12.6328 19.0386 11.9297 18.1948 11.9297C17.3511 11.9297 16.6479 12.6328 16.6479 13.4766V13.8984H16.5073C14.3276 13.8984 12.4995 15.6563 12.4995 17.8359C12.4995 20.0156 14.2573 21.7734 16.5073 21.7734H18.5464C18.9683 21.7734 19.3901 22.125 19.3901 22.5469C19.3901 22.9688 19.0386 23.3203 18.5464 23.3203H14.1167C13.2729 23.3203 12.5698 24.0234 12.5698 24.8672C12.5698 25.7109 13.2729 26.4141 14.1167 26.4141H16.5776V26.8359C16.5776 27.6797 17.2808 28.3828 18.1245 28.3828C18.9683 28.3828 19.6714 27.6797 19.6714 26.8359V26.2031C21.2886 25.7109 22.4136 24.1641 22.4136 22.4766C22.4839 20.2969 20.6558 18.5391 18.4761 18.5391Z" fill="#EFB036"/>
                                        <path d="M42.5933 5.60179C42.8745 4.40648 42.8042 3.21117 42.2417 2.29711C41.6792 1.31273 40.7651 0.609608 39.5698 0.328358C37.8823 -0.0935168 35.9136 0.187733 34.1558 1.24242C33.0308 1.87523 32.187 3.07055 31.4839 4.19555C30.8511 3.00023 30.0073 1.87523 28.812 1.24242C25.648 -0.585704 22.1323 -0.093517 20.7261 2.36742C19.812 3.91429 20.0933 5.81273 21.1479 7.42992H4.62451C2.23389 7.42992 0.265137 9.39867 0.265137 11.7893V28.594C0.265137 30.9846 2.23389 32.9534 4.62451 32.9534H37.1089C39.4995 32.9534 41.4683 30.9846 41.4683 28.594V11.0159C41.4683 10.1018 41.1167 9.32836 40.6245 8.69554C41.6089 7.78148 42.312 6.72679 42.5933 5.60179ZM35.7026 3.9143C36.687 3.3518 37.8823 3.14086 38.7261 3.3518C39.0776 3.42211 39.3589 3.63305 39.4995 3.84398C39.6401 4.12523 39.6401 4.54711 39.5698 4.75805C39.3589 5.6018 38.5854 6.51586 37.6011 7.07836C37.3901 7.21898 37.1792 7.28929 36.8979 7.35961H33.5933C34.0151 6.02367 34.7886 4.40648 35.7026 3.9143ZM25.437 7.07836C23.8198 6.16429 23.0464 4.61742 23.4683 3.84398C23.8901 3.07055 25.648 2.92992 27.2651 3.9143C28.1792 4.4768 28.9526 6.02367 29.4448 7.35961H26.1401C25.8589 7.28929 25.5776 7.21898 25.437 7.07836ZM3.4292 28.5237V11.719C3.4292 11.0159 3.9917 10.4534 4.69482 10.4534H29.937V29.719H4.62451C3.92139 29.7893 3.4292 29.2268 3.4292 28.5237ZM38.3745 28.5237C38.3745 29.2268 37.812 29.7893 37.1089 29.7893H33.0308V10.5237H37.812C38.0933 10.5237 38.3745 10.7346 38.3745 11.0862V28.5237Z" fill="#EFB036"/>
                                    </svg>
                                    <span class="font-medium text-[16px] text-[#EFB036]">Cash</span>
                                </button>
                                <button type="button" id="button-pay" class="button-pay w-[107px] h-[90px] bg-[#E5E1DA] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF] hover:border-[#FADA7A] hover:border-[5px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                        <g clip-path="url(#clip0_1251_3942)">
                                          <path d="M33.3328 31.0003C33.3328 31.6192 33.087 32.2127 32.6494 32.6502C32.2118 33.0878 31.6184 33.3337 30.9995 33.3337H28.3328C27.8908 33.3337 27.4669 33.5093 27.1543 33.8218C26.8418 34.1344 26.6662 34.5583 26.6662 35.0003C26.6662 35.4424 26.8418 35.8663 27.1543 36.1788C27.4669 36.4914 27.8908 36.667 28.3328 36.667H30.9995C32.5024 36.667 33.9437 36.07 35.0065 35.0073C36.0692 33.9446 36.6662 32.5032 36.6662 31.0003V28.3337C36.6662 27.8916 36.4906 27.4677 36.178 27.1551C35.8655 26.8426 35.4415 26.667 34.9995 26.667C34.5575 26.667 34.1336 26.8426 33.821 27.1551C33.5084 27.4677 33.3328 27.8916 33.3328 28.3337V31.0003ZM11.6662 36.667C12.1082 36.667 12.5321 36.4914 12.8447 36.1788C13.1573 35.8663 13.3328 35.4424 13.3328 35.0003C13.3328 34.5583 13.1573 34.1344 12.8447 33.8218C12.5321 33.5093 12.1082 33.3337 11.6662 33.3337H8.99951C8.38067 33.3337 7.78718 33.0878 7.3496 32.6502C6.91201 32.2127 6.66618 31.6192 6.66618 31.0003V28.3337C6.66618 27.8916 6.49059 27.4677 6.17802 27.1551C5.86546 26.8426 5.44154 26.667 4.99951 26.667C4.55748 26.667 4.13356 26.8426 3.821 27.1551C3.50844 27.4677 3.33285 27.8916 3.33285 28.3337V31.0003C3.33285 32.5032 3.92987 33.9446 4.99257 35.0073C6.05528 36.07 7.49662 36.667 8.99951 36.667H11.6662ZM33.3328 11.667C33.3328 12.109 33.5084 12.5329 33.821 12.8455C34.1336 13.1581 34.5575 13.3337 34.9995 13.3337C35.4415 13.3337 35.8655 13.1581 36.178 12.8455C36.4906 12.5329 36.6662 12.109 36.6662 11.667V9.00033C36.6662 7.49743 36.0692 6.05609 35.0065 4.99339C33.9437 3.93068 32.5024 3.33366 30.9995 3.33366H28.3328C27.8908 3.33366 27.4669 3.50925 27.1543 3.82182C26.8418 4.13437 26.6662 4.5583 26.6662 5.00033C26.6662 5.44235 26.8418 5.86628 27.1543 6.17884C27.4669 6.4914 27.8908 6.66699 28.3328 6.66699H30.9995C31.6184 6.66699 32.2118 6.91283 32.6494 7.35041C33.087 7.788 33.3328 8.38149 33.3328 9.00033V11.667ZM3.33285 11.667C3.33285 12.109 3.50844 12.5329 3.821 12.8455C4.13356 13.1581 4.55748 13.3337 4.99951 13.3337C5.44154 13.3337 5.86546 13.1581 6.17802 12.8455C6.49059 12.5329 6.66618 12.109 6.66618 11.667V9.00033C6.66618 8.38149 6.91201 7.788 7.3496 7.35041C7.78718 6.91283 8.38067 6.66699 8.99951 6.66699H11.6662C12.1082 6.66699 12.5321 6.4914 12.8447 6.17884C13.1573 5.86628 13.3328 5.44235 13.3328 5.00033C13.3328 4.5583 13.1573 4.13437 12.8447 3.82182C12.5321 3.50925 12.1082 3.33366 11.6662 3.33366H8.99951C7.49662 3.33366 6.05528 3.93068 4.99257 4.99339C3.92987 6.05609 3.33285 7.49743 3.33285 9.00033V11.667ZM38.3328 21.667C38.7749 21.667 39.1988 21.4914 39.5114 21.1788C39.8239 20.8663 39.9995 20.4424 39.9995 20.0003C39.9995 19.5583 39.8239 19.1344 39.5114 18.8218C39.1988 18.5093 38.7749 18.3337 38.3328 18.3337H1.66618C1.22415 18.3337 0.800228 18.5093 0.487667 18.8218C0.175106 19.1344 -0.000488281 19.5583 -0.000488281 20.0003C-0.000488281 20.4424 0.175106 20.8663 0.487667 21.1788C0.800228 21.4914 1.22415 21.667 1.66618 21.667H38.3328Z" fill="#EFB036"/>
                                        </g>
                                        <defs>
                                          <clipPath id="clip0_1251_3942">
                                            <rect width="40" height="40" fill="white" transform="matrix(-1 0 0 -1 39.9995 40)"/>
                                          </clipPath>
                                        </defs>
                                      </svg>
                                    <span class="font-medium text-[16px] text-[#EFB036]">Qris</span>
                                </button>
                            </div>

                            <button  class="w-full h-[40px] bg-[#FADA7A] rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#F2E5BF]">
                                <span class="font-semibold text-[15px] text-[#000000]">Proses Pesanan</span>
                            </button>
                        </div>

                    </form>

            </div>
        </div>


            </div>
        </div>


    </div>


    @endsection
