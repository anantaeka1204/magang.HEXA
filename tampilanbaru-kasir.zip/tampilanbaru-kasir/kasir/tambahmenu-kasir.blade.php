    @extends('layout.master-kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

        <div class="flex items-center justify-between w-full">
            <!-- Menu & Tambah Menu -->
            <div class="flex items-center gap-[50px]">
                <span class="text-[24px] font-bold">Menu</span>
                <!-- Button Tambah Menu -->
                <div class="bg-[#FADA7A] text-black px-[40px] py-2 border border-1 border-[rgba(0,0,0,0.08)] rounded-[15px] cursor-pointer hover:bg-[#FADA7A] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)]">
                    <a href="/kasir/tambahmenu-kasir" class="flex items-center gap-2 text-[16px] font-normal">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path d="M11.002 19.5V13.5H5.00195V11.5H11.002V5.5H13.002V11.5H19.002V13.5H13.002V19.5H11.002Z" fill="black"/>
                      </svg>
                      Tambah Menu
                    </a>
                </div>
            </div>

            <!-- Search -->
            <div class="search-menu flex items-center px-2 py-2 rounded-[16px] shadow-sm w-[226px] border border-1 border-black">
                <input type="text" placeholder="Cari Menu"
                    class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[180px]">
                <!-- Button Search -->
                <button class="flex items-center justify-center rounded-full icon-search">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                        <path d="M21.4172 19.2078L17.4508 15.2414C18.2703 14.0062 18.75 12.5273 18.75 10.9375C18.75 6.62969 15.2453 3.125 10.9375 3.125C6.62969 3.125 3.125 6.62969 3.125 10.9375C3.125 15.2453 6.62969 18.75 10.9375 18.75C12.5273 18.75 14.0062 18.2703 15.2414 17.4508L19.2078 21.4172C19.8172 22.0273 20.8078 22.0273 21.4172 21.4172C22.0273 20.807 22.0273 19.818 21.4172 19.2078ZM5.46875 10.9375C5.46875 7.92187 7.92187 5.46875 10.9375 5.46875C13.9531 5.46875 16.4062 7.92187 16.4062 10.9375C16.4062 13.9531 13.9531 16.4062 10.9375 16.4062C7.92187 16.4062 5.46875 13.9531 5.46875 10.9375Z" fill="black" fill-opacity="0.4"/>
                    </svg>
                </button>
            </div>
        </div>


        <!-- Button Menu Kategori -->
        <hr class="border-[1px] mt-[20px] border-black/15">

        <!-- Input Menu -->
        <div class="w-full mt-[40px]">
            <form>
                <div class="grid grid-cols-2 gap-x-[50px] gap-y-[40px] items-center justify-center">
                    <!-- Nama Menu -->
                    <div>
                        <label class="block text-[16px] font-normal pb-[15px]">Nama Menu :</label>
                        <input type="text" class="w-full p-2 border border-black rounded-[10px] focus:ring-2 ">
                    </div>

                    <!-- Harga -->
                    <div>
                        <label class="block text-[16px] font-normal pb-[15px]">Harga :</label>
                        <input type="number" class="w-full p-2 border border-black rounded-[10px] focus:ring-2 ">
                    </div>

                    <!-- Kolom Kiri -->
                    <div class="self-start">
                        <label class="block mb-2 text-[16px] font-normal pb-[15px]">Deskripsi Menu :</label>
                        <textarea class="w-full p-2 border border-black rounded-[10px] h-[272px]"></textarea>
                    </div>

                    <!-- Kolom Kanan -->
                    <div>
                        <div class="mb-[30px]">
                            <label class="block mb-2 text-[16px] font-normal pb-[15px]">Kategori :</label>
                            <select class="w-full p-2 bg-white border border-black rounded-[10px]">
                                <option></option>
                                <option>Makanan</option>
                                <option>Minuman</option>
                                <option>Snack</option>
                            </select>
                        </div>

                        <div class="mb-[25px] flex items-start gap-[50px]">
                            <div class="flex flex-col items-start gap-6 lg:flex-row">
                                <!-- Upload Gambar-->
                                <div>
                                  <label class="block mb-1 text-[16px] font-normal pb-[15px]">File Gambar Menu :</label>

                                  <div class="relative">
                                    <div class="px-2 py-2 rounded-[10px] w-[226px] border-[1px] border-black flex items-center">
                                      <!-- Icons file -->
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M16 2.75H8C6.067 2.75 4.5 4.317 4.5 6.25V17.75C4.5 19.683 6.067 21.25 8 21.25H16C17.933 21.25 19.5 19.683 19.5 17.75V6.25C19.5 4.317 17.933 2.75 16 2.75Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8.5 6.75488H15.5M8.5 10.7549H15.5M8.5 14.7549H12" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      </svg>
                                      <span class="ml-2 text-[16px] text-[#686D76]">Pilih File</span>
                                    </div>

                                    <input type="file" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer">
                                  </div>
                                </div>

                                <!-- Gambar -->
                                <div>
                                  <img src="/images/keripik pisang.jpg" class="h-[170px] w-[170px] rounded-[10px] mt-[10px]">
                                </div>
                              </div>

                        </div>


                    </div>

                </div>

                <!-- Tombol Batal dan Tambah-->
                <div class="flex justify-between gap-x-[50px] mt-[10px]">
                    <button id="button" type="reset"
                       class="w-full py-3 text-[16px] font-semibold text-white bg-[#BB1717] rounded-full shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] hover:bg-[#bb17179d] flex items-center justify-center">
                        Batal
                    </button>
                    <button id="button" type="submit"
                       class="w-full py-3 text-[16px] font-semibold text-black bg-[#FADA7A] rounded-full shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] hover:bg-[#fada7a85] flex items-center justify-center">
                        Tambah
                    </button>
                </div>
            </form>
        </div>


    </div>

    @endsection
