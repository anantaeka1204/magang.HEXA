@extends('layout.master-kasir')

@section('title-kasir', 'Menu Minuman Kasir')

@section('content')

<div class="relative p-[50px] pt-[20px] content">

    <div class="flex items-center justify-between w-full">
        <!-- Menu & Tambah Menu -->
        <div class="flex items-center gap-[50px]">
            <span class="text-[32px] font-bold">Menu</span>
            <!-- Button Tambah Menu -->
            <div class="bg-[#ffffff] text-black px-[40px] py-2 border border-1 border-[rgba(0,0,0,0.08)] rounded-[15px] cursor-pointer hover:bg-[#FADA7A] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)]">
                <a href="/kasir/tambahmenu-kasir" class="flex items-center gap-2 text-[16px] font-normal">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                    <path d="M11.002 19.5V13.5H5.00195V11.5H11.002V5.5H13.002V11.5H19.002V13.5H13.002V19.5H11.002Z" fill="black"/>
                  </svg>
                  Tambah Menu
                </a>
            </div>
        </div>

        <!-- Search -->
        <div class="search-menu flex items-center px-2 py-2 rounded-[16px] shadow-sm w-[226px] border border-1 border-black">
            <input type="text" placeholder="Cari Menu"
                class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[180px]">
            <!-- Button Search -->
            <button class="flex items-center justify-center rounded-full icon-search">
                <!-- Icons Search -->
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                    <path d="M21.4172 19.2078L17.4508 15.2414C18.2703 14.0062 18.75 12.5273 18.75 10.9375C18.75 6.62969 15.2453 3.125 10.9375 3.125C6.62969 3.125 3.125 6.62969 3.125 10.9375C3.125 15.2453 6.62969 18.75 10.9375 18.75C12.5273 18.75 14.0062 18.2703 15.2414 17.4508L19.2078 21.4172C19.8172 22.0273 20.8078 22.0273 21.4172 21.4172C22.0273 20.807 22.0273 19.818 21.4172 19.2078ZM5.46875 10.9375C5.46875 7.92187 7.92187 5.46875 10.9375 5.46875C13.9531 5.46875 16.4062 7.92187 16.4062 10.9375C16.4062 13.9531 13.9531 16.4062 10.9375 16.4062C7.92187 16.4062 5.46875 13.9531 5.46875 10.9375Z" fill="black" fill-opacity="0.4"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- Garis -->
    <hr class="border mt-[20px] border-black/15">

        <!-- Button Menu Kategori -->
        <div class="pt-[20px] pb-[10px] overflow-x-auto set-scroll">
            <div class="flex gap-[10px]">
                <a href="/kasir/" class="semua-menu bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="text-[16px] font-medium">Semua Menu</span>
                </a>
                <a href="/kasir/menumakanan-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M5.32812 16.0742V19.0695C6.2433 20.1914 7.39682 21.0953 8.70492 21.7157C10.013 22.3361 11.4429 22.6574 12.8906 22.6563C16.2688 22.6563 19.2469 20.9406 21 18.3336V14.1352C20.4 18.075 16.9977 21.0938 12.8906 21.0938C9.48906 21.0938 6.57109 19.0234 5.32812 16.0742ZM19.5547 8.10626V6.76095C19.5521 6.46422 19.6007 6.16926 19.6984 5.88907C17.8774 4.11379 15.4338 3.12168 12.8906 3.12501C10.6147 3.12163 8.40971 3.91645 6.65937 5.3711L6.66328 5.41876L6.66406 5.43985V7.54923C7.43357 6.65072 8.38865 5.92963 9.46355 5.43561C10.5384 4.94159 11.7076 4.68636 12.8906 4.68751C15.6359 4.68751 18.0656 6.03595 19.5547 8.10626Z" fill="black"/>
                            <path d="M19.1406 12.8908C19.1406 14.5484 18.4821 16.1381 17.31 17.3102C16.1379 18.4823 14.5482 19.1408 12.8906 19.1408C11.233 19.1408 9.64331 18.4823 8.47121 17.3102C7.29911 16.1381 6.64062 14.5484 6.64062 12.8908C6.64062 11.2332 7.29911 9.64349 8.47121 8.47139C9.64331 7.29929 11.233 6.64081 12.8906 6.64081C14.5482 6.64081 16.1379 7.29929 17.31 8.47139C18.4821 9.64349 19.1406 11.2332 19.1406 12.8908ZM12.8906 18.3596C13.6088 18.3596 14.3199 18.2181 14.9834 17.9433C15.6469 17.6684 16.2498 17.2656 16.7576 16.7578C17.2654 16.25 17.6683 15.6471 17.9431 14.9836C18.2179 14.3201 18.3594 13.609 18.3594 12.8908C18.3594 12.1726 18.2179 11.4615 17.9431 10.798C17.6683 10.1345 17.2654 9.53164 16.7576 9.02382C16.2498 8.516 15.6469 8.11317 14.9834 7.83834C14.3199 7.56351 13.6088 7.42206 12.8906 7.42206C11.4402 7.42206 10.0492 7.99823 9.02363 9.02382C7.99805 10.0494 7.42188 11.4404 7.42188 12.8908C7.42188 14.3412 7.99805 15.7322 9.02363 16.7578C10.0492 17.7834 11.4402 18.3596 12.8906 18.3596ZM23.4297 6.20331C23.4297 5.50018 22.8594 4.92987 22.1562 4.92987C21.1406 4.92987 20.3281 5.75018 20.3359 6.758V11.0939C20.3359 12.0728 20.9031 12.9494 21.7812 13.3463V20.0783C21.7812 20.4846 22.1094 20.8127 22.5156 20.8127H22.6953C23.1016 20.8127 23.4297 20.4846 23.4297 20.0783V6.20331ZM5.32813 4.92987C5.18723 4.92987 5.0521 4.98584 4.95247 5.08547C4.85285 5.1851 4.79688 5.32022 4.79688 5.46112V7.56268C4.79688 7.71893 4.67188 7.83612 4.52344 7.83612C4.36719 7.83612 4.25 7.71112 4.25 7.56268V5.48456C4.25 5.1955 4.02344 4.93768 3.73438 4.92987C3.42969 4.92206 3.17969 5.16425 3.17969 5.46112V7.56268C3.17969 7.71893 3.05469 7.83612 2.90625 7.83612C2.75 7.83612 2.63281 7.71112 2.63281 7.56268V5.48456C2.63281 5.1955 2.40625 4.93768 2.11719 4.92987C1.8125 4.92206 1.5625 5.16425 1.5625 5.46112V9.03925C1.5625 9.74393 1.90391 10.3728 2.42891 10.765C2.89844 11.0299 2.89844 12.2424 2.89844 12.2424V20.0705C2.89844 20.4767 3.22656 20.8049 3.63281 20.8049H3.8125C4.21875 20.8049 4.54688 20.4767 4.54688 20.0705V12.2424C4.54688 12.2424 4.54688 11.0775 5.01641 10.765C5.28503 10.5645 5.5032 10.3041 5.6536 10.0045C5.804 9.70497 5.88248 9.37446 5.88281 9.03925V5.46112C5.8749 5.31876 5.81322 5.18471 5.71025 5.08609C5.60728 4.98747 5.4707 4.93163 5.32813 4.92987Z" fill="black"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Makanan</span>
                </a>
                <a href="/kasir/menuminuman-kasir" class="menu-makanan bg-[#FADA7A] 5px] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M15.0835 1.04199H20.8335V3.12533H16.646L15.9689 5.43991H20.9064L19.6439 23.9587H6.4762L5.56995 10.7066C3.61995 10.2743 2.0835 8.58262 2.0835 6.48158C2.0835 4.06491 4.07725 2.14199 6.49079 2.14199C8.546 2.14199 10.296 3.5347 10.772 5.43991H13.797L15.0835 1.04199ZM13.1877 7.52324H7.44287L7.6887 11.1503L11.9252 11.8389L13.1877 7.52324ZM12.496 14.042L7.83454 13.2847L8.42204 21.8753H17.697L18.1668 14.9837L12.5002 14.043L12.496 14.042ZM18.3095 12.8962L18.6762 7.52324H15.3585L13.996 12.1795L18.3095 12.8962ZM8.55329 5.43887C8.35212 5.06828 8.05386 4.75945 7.69052 4.54548C7.32717 4.33151 6.91244 4.22047 6.49079 4.22428C5.18766 4.22533 4.16683 5.25553 4.16683 6.48158C4.16683 7.31178 4.66683 8.06803 5.41787 8.45658L5.21266 5.43991L8.55329 5.43887Z" fill="black"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Minuman</span>
                </a>
                <a href="/kasir/menusnack-kasir" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M16.9937 4.11416C16.7926 3.54516 16.4272 3.04862 15.9437 2.68743C15.4603 2.32625 14.8805 2.11666 14.2778 2.0852C13.6752 2.05375 13.0767 2.20184 12.5583 2.51074C12.0399 2.81963 11.6248 3.27543 11.3655 3.82041C11.0426 4.49749 10.2312 5.11416 9.48325 5.18291C8.67402 5.25663 7.91441 5.60519 7.33079 6.17059C6.74718 6.736 6.37472 7.48417 6.27539 8.29066C6.17605 9.09715 6.35582 9.91335 6.7848 10.6035C7.21377 11.2936 7.86609 11.8161 8.63325 12.0839M8.63325 12.0839C8.30855 12.342 8.03991 12.6636 7.84378 13.0291C7.64765 13.3945 7.52814 13.7962 7.49258 14.2094C7.45701 14.6226 7.50613 15.0388 7.63693 15.4324C7.76774 15.826 7.97747 16.1888 8.2533 16.4985C8.52913 16.8083 8.86526 17.0585 9.24113 17.2339C9.61699 17.4092 10.0247 17.5061 10.4393 17.5185C10.8538 17.5308 11.2666 17.4585 11.6522 17.3059C12.0379 17.1533 12.3884 16.9236 12.6822 16.6308C12.7083 16.6058 12.7399 16.5872 12.7745 16.5765C12.8091 16.5659 12.8456 16.5635 12.8813 16.5696C12.917 16.5757 12.9507 16.59 12.9798 16.6115C13.0089 16.633 13.0326 16.661 13.0489 16.6933C13.4333 17.537 14.1319 18.1972 14.9958 18.5335C15.8598 18.8697 16.8209 18.8553 17.6745 18.4935C18.528 18.1316 19.2066 17.4508 19.5657 16.596C19.9247 15.7413 19.9359 14.7801 19.5968 13.9173M8.63325 12.0839C9.21938 11.62 9.95553 11.3875 10.7018 11.4307C11.4481 11.474 12.1525 11.7898 12.6812 12.3183M16.2749 7.28812C16.6821 6.88067 16.9657 6.36629 17.0929 5.80444C17.2201 5.2426 17.1857 4.65623 16.9937 4.11312C17.1467 3.68213 17.3947 3.29109 17.7193 2.96895C18.0439 2.64682 18.4369 2.40184 18.869 2.25216C19.3012 2.10248 19.7615 2.05193 20.2158 2.10426C20.6702 2.1566 21.1069 2.31047 21.4937 2.55448C21.8805 2.7985 22.2075 3.1264 22.4503 3.51391C22.6932 3.90142 22.8458 4.33861 22.8969 4.79309C22.9479 5.24758 22.896 5.70772 22.7451 6.13943C22.5941 6.57115 22.348 6.96338 22.0249 7.28707C21.7041 7.60791 21.7041 8.40478 22.0239 8.72457C22.4666 9.16735 22.7623 9.7357 22.8707 10.3524C22.9791 10.9691 22.8951 11.6042 22.63 12.1714C22.3648 12.7387 21.9315 13.2105 21.3888 13.5229C20.8461 13.8352 20.2205 13.9729 19.5968 13.9173M19.5968 13.9173C19.0694 13.8702 18.5633 13.6867 18.1283 13.3848C17.6932 13.0829 17.3442 12.673 17.1155 12.1954M2.08325 22.9162L8.33325 16.6662" stroke="black" stroke-width="1.5625" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Snack</span>
                </a>
            </div>
        </div>

        <!-- Menu Minuman -->
    <p class="font-semibold text-[20px] pt-[20px] pb-[20px]">Minuman</p>

    <!-- Menu Minuman -->
    <div class="grid items-center justify-around gap-[20px] grid-cols-2 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5">

        <!-- Card 1 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/air mineral.jpg" alt="Air Mineral" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Air Mineral</h2>
                <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 3.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="7" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/es teh.jpg" alt="Es Teh" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Es Teh</h2>
                <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 3.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="8" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/teh hangat.jpg" alt="Teh Panas" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Teh Panas</h2>
                <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 2.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="9" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

       <!-- Card 4 -->
       <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/es jeruk.jpg" alt="Es Jeruk" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Es Jeruk</h2>
                <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 4.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="10" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/jeruk hangat.jpg" alt="Jeruk Panas" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Jeruk Panas</h2>
                <p class="text-[14px] font-medium mt-[10px]">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 4.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="11" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
            <!-- Gambar -->
            <img src="/images/jus jambu.jpg" alt="Jus Jambu" class="object-cover w-[239px] h-[202px] saturate-0">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4 pt-1">
                <h2 class="text-[20px] font-bold">Jus Jambu</h2>
                <p class="text-[14px] text-[#CA2A2A] font-medium mt-[10px]">Stok Habis</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-semibold text-[18px]">Rp. 8.000</p>
                    <!-- Icons Sampah dan + -->
                    <div class="flex space-x-3">
                        <button data-item-id="12" class="deleteBtn w-[30px] h-[30px] bg-[#CA2A2A] rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-[20px] h-[20px] text-white">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                            </svg>
                        </button>
                        <!-- Icons + -->
                        <a href="/kasir/pesanmenuall-kasir" class="w-[30px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                class="w-[20px] h-[20px] object-cover">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>

</div>

    <!-- Pop-up Sampah -->
    <div id="deleteModal" class="fixed inset-0 items-start justify-center hidden pt-[300px] bg-[rgba(0,0,0,0.5)]">
        <div class="bg-white w-[377px] h-[182px] p-9 pt-3 rounded-[10px]">
            <div class="p-2">
                <p class="text-[20px] font-bold text-center">Apakah ingin menghapus <br>bakso campur?</p>
                <div class="flex justify-center mt-[30px] space-x-[45px]">
                    <button id="confirmDelete" class="w-[90px] h-[40px] text-medium text-[16px] text-white bg-red-600 rounded-[4px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.25)]">Hapus</button>
                    <button id="cancelDelete" class="w-[90px] h-[40px] bg-gray-300 text-medium text-[16px] rounded-[4px] shadow-[0px_4px_16px_0px_rgba(0,_0,_0,_0.10)]">Batal</button>
                </div>
            </div>
        </div>
    </div>


</div>

@endsection

<script>
// Untuk Pop Up Hapus
document.addEventListener("DOMContentLoaded", function () {
const deleteBtns = document.querySelectorAll(".deleteBtn");
const deleteModal = document.getElementById("deleteModal");
const confirmDelete = document.getElementById("confirmDelete");
const cancelDelete = document.getElementById("cancelDelete");
const itemIdDisplay = document.getElementById("itemIdDisplay"); // Elemen untuk menampilkan ID item

let itemIdToDelete = null;

deleteBtns.forEach((deleteBtn) => {
    deleteBtn.addEventListener("click", () => {
        itemIdToDelete = deleteBtn.getAttribute("data-item-id");

        if (itemIdDisplay) {
            itemIdDisplay.textContent = itemIdToDelete;
        }

        deleteModal.classList.remove("hidden");
        deleteModal.classList.add("flex");
    });
});

cancelDelete.addEventListener("click", () => {
    deleteModal.classList.remove("flex");
    deleteModal.classList.add("hidden");
});

confirmDelete.addEventListener("click", () => {
    if (itemIdToDelete) {
        console.log(`Item dengan ID ${itemIdToDelete} akan dihapus`); // Lakukan aksi hapus di sini
    }

    deleteModal.classList.remove("flex");
    deleteModal.classList.add("hidden");
});
});
</script>

