    @extends('layout.master-kasir')

    @section('tittle-kasir', 'Riwayat Pesanan Kasir')

    @section('content')

    <div class="relative p-[50px] pt-[20px] content">

    <p class="font-bold text-[24px] pt-[10px] pb-[20px]">Riwayat Pesanan</p>

    <div class="search-menu flex items-center px-2 py-2 rounded-sm shadow-sm w-[300px] border border-1 border-[#E2E8F0]">
        <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
            <!-- Icons Search -->
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#808080" class="w-[20px] h-[20px]">
                <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
            </svg>
        </button>
        <input type="text" placeholder="Cari Menu"
            class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[280px]">
    </div>

    <div class="pt-[40px]"></div>

    <!-- Tabel Riwayat Pesanan -->
    <div class="overflow-hidden border rounded-[10px]">
        <table class="w-full rounded-[10px]">
                <thead>
                    <tr class="bg-[#F4F4F5]">
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-center">#</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">Nama Pelanggan</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">No Meja</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">Pembayaran</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">Menu</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">Status Pesanan</th>
                        <th class="py-2 px-4 border-r font-medium text-[13px] text-[#000000] text-left">Status Pembayaran</th>
                        <th class="py-2 px-4 font-medium text-[13px] text-[#000000] text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Riwayat 1 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#CA2A2A] bg-[rgba(202,42,42,0.08)] border-[#CA2A2A] border-[1px] rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#CA2A2A] rounded-[5px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 2 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#EFB036] bg-[rgba(239,176,54,0.08)] border-[#EFB036] border-[1px] rounded-[15px] mx-auto">
                                Diproses
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                      <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                    </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 3 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#6CB56B] bg-[rgba(108,181,107,0.08)] border-[#6CB56B] border-[1px] rounded-[15px] mx-auto">
                                Selesai
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                      <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                    </svg>
                                  </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 4 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#EFB036] bg-[rgba(239,176,54,0.08)] border-[#EFB036] border-[1px] rounded-[15px] mx-auto">
                                Diproses
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                      <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                    </svg>
                                  </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 5 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Tunai</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#CA2A2A] bg-[rgba(202,42,42,0.08)] border-[#CA2A2A] border-[1px] rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#CA2A2A] rounded-[5px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 6 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Tunai</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#CA2A2A] bg-[rgba(202,42,42,0.08)] border-[#CA2A2A] border-[1px] rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#CA2A2A] rounded-[5px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 7 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#CA2A2A] bg-[rgba(202,42,42,0.08)] border-[#CA2A2A] border-[1px] rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#CA2A2A] rounded-[5px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 8 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px] font-medium">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">01</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px] font-normal">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[10px] font-normal text-[#CA2A2A] bg-[rgba(202,42,42,0.08)] border-[#CA2A2A] border-[1px] rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[10px] font-normal text-[#FFFFFF] bg-[#CA2A2A] rounded-[5px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/kasir/detailpesanan-kasir" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>



                </tbody>
            </table>
        </div>
    </div>



    <div>

    @endsection
