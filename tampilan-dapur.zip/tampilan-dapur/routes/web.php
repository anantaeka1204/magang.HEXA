<?php

use Illuminate\Support\Facades\Route;

/*Route::get('/', function () {
    return view('welcome');
});*/


//Tampilan Dapur

Route::get('/dapur/stockmenusemua-dapur', function () {
    return view('dapur.dashboard-dapur');
});

Route::get('/dapur/stockmenumakanan-dapur', function () {
    return view('dapur.stockmenumakanan-dapur');
});

Route::get('/dapur/stockmenuminuman-dapur', function () {
    return view('dapur.stockmenuminuman-dapur');
});

Route::get('/dapur/stockmenusnack-dapur', function () {
    return view('dapur.stockmenusnack-dapur');
});

Route::get('/dapur/riwayatpesananall-dapur', function () {
    return view('dapur.riwayatpesananall-dapur');
});

Route::get('/dapur/riwayatpesananmenunggu-dapur', function () {
    return view('dapur.riwayatpesananmenunggu-dapur');
});

Route::get('/dapur/riwayatpesanandikonfirmasi-dapur', function () {
    return view('dapur.riwayatpesanandikonfirmasi-dapur');
});

Route::get('/dapur/riwayatpesananproses-dapur', function () {
    return view('dapur.riwayatpesananproses-dapur');
});

Route::get('/dapur/riwayatpesananselesai-dapur', function () {
    return view('dapur.riwayatpesananselesai-dapur');
});

Route::get('/dapur/detailriwayatpesanan-dapur', function () {
    return view('dapur.detailriwayatpesanan-dapur');
});



//Tampilan Kasir
Route::get('/kasir/login', function () {
    return view('kasir.login');
});

Route::get('/kasir/menumakanan-kasir', function () {
    return view('kasir.menumakanan-kasir');
});

Route::get('/kasir/menuminuman-kasir', function () {
    return view('kasir.menuminuman-kasir');
});

Route::get('/kasir/menusnack-kasir', function () {
    return view('kasir.menusnack-kasir');
});

Route::get('/kasir/riwayatpesanan-kasir', function () {
    return view('kasir.riwayatpesanan-kasir');
});

Route::get('/kasir/tambahmenu-kasir', function () {
    return view('kasir.tambahmenu-kasir');
});

Route::get('/kasir/pesanmenu-kasir', function () {
    return view('kasir.pesanmenu-kasir');
});

Route::get('/kasir/detailpesanan-kasir', function () {
    return view('kasir.detailpesanan-kasir');
});

Route::get('/kasir/menusemua-kasir', function () {
    return view('kasir.menusemua-kasir');
});




//Tampilan Pelanggan
Route::get('/', function () {
    return view('pelanggan.input-nomeja');
});

Route::get('/pelanggan/home', function () {
    return view('pelanggan.home');
});

Route::get('/pelanggan/menu-makanan', function () {
    return view('pelanggan.menu-makanan');
});

Route::get('/pelanggan/menu-minuman', function () {
    return view('pelanggan.menu-minuman');
});

Route::get('/pelanggan/menu-snack', function () {
    return view('pelanggan.menu-snack');
});

Route::get('/pelanggan/menu-detail', function () {
    return view('pelanggan.menu-detail');
});

Route::get('/pelanggan/menu-keranjang', function () {
    return view('pelanggan.menu-keranjang');
});

Route::get('/pelanggan/menu-pembayaranqris', function () {
    return view('pelanggan.menu-pembayaranqris');
});

Route::get('/pelanggan/menu-pembayarantunai', function () {
    return view('pelanggan.menu-pembayarantunai');
});

Route::get('/pelanggan/pesanan-livetracking', function () {
    return view('pelanggan.pesanan-livetracking');
});

Route::get('/pelanggan/splitbill-scan', function () {
    return view('pelanggan.splitbill-scan');
});

Route::get('/pelanggan/splitbill-konfirmasiitem', function () {
    return view('pelanggan.splitbill-konfirmasiitem');
});

Route::get('/pelanggan/splitbill-bagibill', function () {
    return view('pelanggan.splitbill-bagibill');
});

Route::get('/pelanggan/splitbill-jumlahtotal', function () {
    return view('pelanggan.splitbill-jumlahtotal');
});

Route::get('/pelanggan/pesanan-riwayatpesanan', function () {
    return view('pelanggan.pesanan-riwayatpesanan');
});


Route::get('/ujicoba1', function () {
    return view('ujicoba1');
});



