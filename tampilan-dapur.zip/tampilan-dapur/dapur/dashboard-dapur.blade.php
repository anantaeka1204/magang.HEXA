@extends('layout.master-dapur')

@section('content')

<div class="relative p-[50px] pt-[20px] content">

    <div class="flex items-center justify-between w-full">
        <!-- Bagian Kiri: Menu & Tambah Menu -->
        <div class="flex items-center space-x-5">
            <span class="text-[24px] font-bold">Menu</span>
        </div>

        <!-- Search -->
        <div class="search-menu flex items-center px-2 py-2 rounded-3xl shadow-sm w-[226px] border border-1 border-black">
            <input type="text" placeholder="Cari Menu"
                class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[170px]">
            <!-- Button Search -->
            <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
                <!-- Icons Search -->
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-[20px] h-[20px]">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                </svg>
            </button>
        </div>
    </div>

    <!-- Button Menu Kategori -->
    <hr class="border mt-[20px] border-black/15">

        <div class="pt-[20px] mb-[20px] overflow-x-auto set-scroll whitespace-nowrap">
            <div class="flex space-x-4 flex-nowrap">
                <a href="/dapur/dashboard-dapur" class="menu-makanan bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm flex justify-center items-center group transition">
                    <span class="text-[14px] md:text-[16px] font-medium">Semua Menu</span>
                </a>
                <a href="/dapur/stockmenumakanan-dapur" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <img src="/images/makanan-pelanggan.png" alt="Makanan"
                            class="w-[25px] h-[25px] object-cover aspect-square">
                    </span>
                    <span class="text-[14px] md:text-[16px] font-medium justify-start">Makanan</span>
                </a>
                <a href="/dapur/stockmenuminuman-dapur" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <img src="/images/minuman-pelanggan.png" alt="Minuman"
                            class="w-[25px] h-[25px] object-cover aspect-square">
                    </span>
                    <span class="text-[14px] md:text-[16px] font-medium justify-start">Minuman</span>
                </a>
                <a href="/dapur/stockmenusnack-dapur" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A]  border border-1 px-2 md:px-3 py-2 min-w-[125px] w-full md:w-auto rounded-3xl shadow-sm items-center flex space-x-2 group transition">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <img src="/images/snack-pelanggan.png" alt="Snack"
                            class="w-[25px] h-[25px] object-cover aspect-square">
                    </span>
                    <span class="text-[14px] md:text-[16px] font-medium justify-start">Snack</span>
                </a>
            </div>
        </div>

    <!-- Menu Makanan -->
    <p class="font-semibold text-[24px] pt-[20px] pb-[20px] pl-0">Makanan</p>

        <!-- Menu Makanan -->
        <div class="grid items-center justify-around grid-cols-5">

            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                         <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="1" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                         <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="2" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="3" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

           <!-- Card 4 -->
           <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="4" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="5" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="6" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>


    </div>


    <!-- Menu Minuman -->
    <p class="font-semibold text-[24px] pt-[20px] pb-[20px] pl-0">Minuman</p>

        <!-- Menu Makanan -->
        <div class="grid items-center justify-around grid-cols-5">
            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="7" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="8" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4">
                    <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                    <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                        <!-- Edit Stock -->
                        <div class="flex space-x-3">
                            <a data-item-id="9" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] ml-[5px]">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

           <!-- Card 4 -->
           <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="10" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="11" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="12" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <!-- Menu Snack -->
    <p class="font-semibold text-[24px] pt-[20px] pb-[20px] pl-0">Snack</p>

    <!-- Menu Snack -->
    <div class="grid items-center justify-around grid-cols-5">
        <!-- Card 1 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="13" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="14" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="overflow-hidden bg-white rounded-lg shadow-lg w-[238px] h-[367px] relative mb-5 flex flex-col">
            <!-- Gambar -->
            <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

            <!-- Konten Teks -->
            <div class="flex flex-col flex-grow p-4">
                <h2 class="text-sm font-bold sm:text-md md:text-lg">Bakso Campur</h2>
                <p class="text-[13px] font-light text-[#686D76] sm:text-sm">Isi: Pentol, tahu, gorengan</p>
                <p class="mt-2 text-xs font-bold sm:text-sm">Stok: 50</p>

                <!-- Harga dan Tombol -->
                <div class="flex items-center justify-between mt-auto">
                    <p class="font-bold text-md sm:text-lg">Rp. 15.000</p>
                    <!-- Edit Stock -->
                    <div class="flex space-x-3">
                        <a data-item-id="15" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span class="text-[11px] ml-[5px]">Edit Stock</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>



    </div>

<!-- Modal Pop-up Edit Stock -->
<div id="editstockModal" class="fixed inset-0 items-center justify-center hidden bg-black bg-opacity-50">
    <!-- Modal Content -->
    <div class="bg-white p-6 rounded-lg shadow-lg w-[595px] h-[419px]">
       <h2 class="mb-[70px] text-[28px] font-normal text-center mt-[30px]">Edit stock bakso campur</h2>

       <!-- Stock Input -->
       <div class="flex items-center justify-center border rounded-md w-[215px] mx-auto my-[15px] border-black">
           <button id="decreaseStock" class="pr-[20px] py-2 ">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="3" viewBox="0 0 28 3" fill="none">
                   <path d="M26.6562 2.11055H1.34375C0.78125 2.11055 0.265625 1.84492 0.265625 1.49961C0.265625 1.18086 0.734375 0.888672 1.34375 0.888672H26.6562C27.2187 0.888672 27.7344 1.1543 27.7344 1.49961C27.7344 1.81836 27.2187 2.11055 26.6562 2.11055Z" fill="black"/>
               </svg>
           </button>

           <!-- Border Vertikal -->
           <div class="h-[40px] border-l border-black"></div>

           <span id="stockValue" class="px-[30px]">1</span>

           <!-- Border Vertikal -->
           <div class="h-[40px] border-l border-black"></div>

           <button id="increaseStock" class="pl-[20px] py-2">
               <svg xmlns="http://www.w3.org/2000/svg" width="25" height="20" viewBox="0 0 31 31" fill="none">
                   <g clip-path="url(#clip0_1413_2938)">
                     <path d="M28.2019 14.4687H16.155V2.375C16.155 1.8125 15.6863 1.29688 15.0769 1.29688C14.5144 1.29688 13.9988 1.76562 13.9988 2.375V14.4687H1.9519C1.3894 14.4687 0.873779 14.9375 0.873779 15.5469C0.873779 16.1094 1.34253 16.625 1.9519 16.625H14.0457V28.625C14.0457 29.1875 14.5144 29.7031 15.1238 29.7031C15.6863 29.7031 16.2019 29.2344 16.2019 28.625V16.5781H28.2019C28.7644 16.5781 29.28 16.1094 29.28 15.5C29.28 14.9375 28.7644 14.4687 28.2019 14.4687Z" fill="#111928"/>
                   </g>
                   <defs>
                     <clipPath id="clip0_1413_2938">
                       <rect width="30" height="30" fill="white" transform="translate(0.0769043 0.5)"/>
                     </clipPath>
                   </defs>
               </svg>
           </button>
       </div>


       <!-- Action Buttons -->
       <div class="flex justify-center mt-[100px] space-x-[20px]">
           <button id="confirmStock" class="w-full py-2 bg-[#EFB036] rounded">Oke</button>
           <button id="closeModal" class="w-full py-2 bg-[#E5E1DA] rounded">Batal</button>
       </div>
   </div>
</div>

</div>

@endsection

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const editStockBtns = document.querySelectorAll(".editStockBtn");
        const modal = document.getElementById("editstockModal");
        const closeModal = document.getElementById("closeModal");
        const confirmStock = document.getElementById("confirmStock");
        const decreaseStock = document.getElementById("decreaseStock");
        const increaseStock = document.getElementById("increaseStock");
        const stockValue = document.getElementById("stockValue");

        let stockCount = parseInt(stockValue.textContent);

        editStockBtns.forEach(btn => {
            btn.addEventListener("click", function (event) {
                event.preventDefault();
                modal.classList.remove("hidden");
                modal.classList.add("flex");
            });
        });

        closeModal.addEventListener("click", function () {
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        });

        increaseStock.addEventListener("click", function () {
            stockCount++;
            stockValue.textContent = stockCount;
        });

        decreaseStock.addEventListener("click", function () {
            if (stockCount > 1) {
                stockCount--;
                stockValue.textContent = stockCount;
            }
        });

        confirmStock.addEventListener("click", function () {
            alert("Stock berhasil diperbarui: " + stockCount);
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        });
    });
    </script>


