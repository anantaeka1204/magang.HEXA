
@extends('layout.master-dapur')

@section('content')

<div class="relative p-[50px] pt-[20px] content">

    <div class="flex items-center gap-[30px]">
        <a href="/kasir/riwayatpesanan-kasir">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
            </svg>
        </a>
        <span class="font-bold text-[24px] ml-2">Detail Pesanan</span>
    </div>

    <div class="pt-[20px]"></div>

    <div class="pt-2 pb-2 p-14">
        <div class="flex items-center justify-between w-full p-4 border-[#E5E1DA] border rounded-lg">
            <div class="flex flex-col">
                <strong class="text-gray-800">Antrian Pesanan #105482</strong>
                <span class="px-2 py-1 mt-1 text-sm text-yellow-700 bg-yellow-100 rounded w-fit">Meja 01</span>
            </div>
            <!--Menunggu Konfirmasi-->
            <div class="px-[30px] py-1 text-[14px] text-black border-2 border-[#CA2A2A] bg-[rgba(202,42,42,0.45)] rounded-xl">Menunggu Konfirmasi</div>
            <!--Dikonfirmasi-->
            <!--<div class="px-[30px] py-1 text-[14px] text-black border-2 border-[#6CB56B] bg-[rgba(108,181,107,0.45)] rounded-xl">Dikonfirmasi</div>-->
        </div>
    </div>

    <div class="pt-[20px]"></div>

    <div class="pt-2 pb-2 p-14">
        <div class="w-full p-6 rounded-lg border-[#E5E1DA] border">
            <div class="flex flex-col justify-between md:flex-row">
                <!-- Bagian Kiri -->
                <div class="w-full space-y-4 md:w-1/5">
                    <div>
                        <p class="font-semibold">Nama Pelanggan</p>
                        <p class="text-[#5E6470]">Alexandra Bell</p>
                    </div>
                    <div>
                        <p class="font-semibold">Pemesanan</p>
                        <p class="text-[#5E6470]">#105482</p>
                    </div>
                    <div>
                        <p class="font-semibold">Tanggal Pesan</p>
                        <p class="text-[#5E6470]">07 Februari, 2025</p>
                    </div>
                </div>

                <!-- Bagian Tabel -->
                <div class="w-full">
                    <div class="overflow-hidden border rounded-lg">
                        <table class="w-full rounded-lg">
                            <thead>
                                <tr>
                                    <th class="w-[75%] p-2 text-left">List Menu</th>
                                    <th class="w-[10%] p-2 text-center">Jumlah</th>
                                    <th class="w-[15%] p-2 text-center">Sub Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold">Bakso Campur</td>
                                    <td class="p-2 text-center">1</td>
                                    <td class="p-2 text-center">Rp 15.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold">Rawon</td>
                                    <td class="p-2 text-center">3</td>
                                    <td class="p-2 text-center">Rp 22.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold">Es Teh</td>
                                    <td class="p-2 text-center">1</td>
                                    <td class="p-2 text-center">Rp 4.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold">Jeruk Panas</td>
                                    <td class="p-2 text-center">3</td>
                                    <td class="p-2 text-center">Rp 6.000</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-t bg-[#F9FAFC]">
                                    <td class="p-2"></td>
                                    <td class="p-2 text-center font-semibold text-[#4358D1]">Total Harga</td>
                                    <td class="p-2 text-center font-semibold text-[#4358D1] ">Rp. 103.000</td>
                                </tr>
                            </tfoot>
                        </table>


                    </div>
                </div>
            </div>

            <div class="flex justify-end mt-6 mr-[59px]">
                <button class="px-[70px] py-[7px] text-white bg-[#1408FF] rounded text-[14px]">Unduh Nota</button>
            </div>

        </div>


    </div>


<div>

@endsection
