@extends('layout.master-dapur')

@section('content')

<div class="relative p-[50px] pb-[30px] pt-[20px] content">

     <!-- Daftar Pesanan -->
     <div class="flex items-center justify-between mb-[20px]">
        <h2 class="text-3xl font-bold">Daftar Pesanan</h2>
    <!--Notification Masuk-->
        <div id="notification-masuk" class="flex items-center rounded-lg bg-[#FFF6DA] text-black">
            <div class="flex items-center px-20 py-2">
                <span class="mr-2 text-xl">
                    <img src="/images/sendok-garpu.png" alt="Sendok Garpu" class="w-5 h-5">
                </span>
                <span class="font-bold">Hallo Dapur</span>
                <span class="ml-2 font-normal">satu pesanan masuk</span>
            </div>
        </div>
    </div>

    <!-- Status Pesanan -->
    <div class="flex items-center space-x-12 pl-[4px]">
        <h6 class="text-2xl font-bold">5</h6>
        <h6 class="text-2xl font-bold">6</h6>
        <h6 class="text-2xl font-bold">4</h6>

        <!-- Search -->
        <div id="search">
            <div class="relative flex max-w-md pl-6">
                <!-- Icon Pencarian -->
                <div class="absolute inset-y-0 flex items-center left-8">
                    <svg class="w-5 h-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35m2.85-5.15a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>

                <!-- Input Field -->
                <input
                    id="search" name="search" type="text" autocomplete="off"
                    class="min-w-80 flex-auto rounded-xl px-3.5 py-2 pl-10 text-gray-800 placeholder-gray-500 bg-gray-200 focus:outline-2 focus:outline-indigo-500 sm:text-sm"
                    placeholder="Cari Pelanggan">

            </div>
        </div>
    </div>

    <!-- Status Pesanan -->
    <div class="flex items-center space-x-4">
        <p class="font-normal">Baru</p>
        <p class="font-normal">Proses</p>
        <p class="font-normal">Selesai</p>
    </div>

</div>

<hr class="mb-4 border-t-2 border-[#D9D9D9]">

    <!-- Button Status Pesanan -->
    <div id="button-status">
        <div class="flex pl-10 mb-4 space-x-6">
            <a href="/dapur/riwayatpesananall-dapur" class="px-4 py-2 rounded-md bg-[#E5E1DA] hover:bg-[rgba(37,208,246,0.50)] text-black font-normal">Semua Pesanan</a>
            <a href="/dapur/riwayatpesananmenunggu-dapur" class="px-4 py-2 rounded-md bg-[#E5E1DA] hover:bg-[rgba(202,42,42,0.45)] text-black  font-normal">Menunggu</a>
            <a href="/dapur/riwayatpesanandikonfirmasi-dapur" class="px-4 py-2 rounded-md bg-[#E5E1DA] hover:bg-[rgba(67,75,225,0.45)] text-black font-normal">Dikonfimasi</a>
            <a href="/dapur/riwayatpesananproses-dapur" class="px-4 py-2 rounded-md bg-[rgba(239,176,54,0.50)] hover:bg-[rgba(239,176,54,0.50)] text-black font-normal">Proses</a>
            <a href="/dapur/riwayatpesananselesai-dapur" class="px-4 py-2 rounded-md bg-[#E5E1DA] hover:bg-[rgba(108,181,107,0.45)] text-black font-normal">Selesai</a>
        </div>
    </div>

    <!--Table-->
    <div class="relative p-[50px] pb-[30px] pt-[20px] content">

    <!-- Tabel Riwayat Pesanan -->
    <div class="overflow-x-auto rounded-xl border border-[#E5E1DA]">
        <div class="overflow-hidden rounded-lg">
            <table class="min-w-full bg-white border-collapse border-spacing-0">
                <thead>
                    <tr class="bg-[#F4F4F5]">
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-center">#</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Nama Pelanggan</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">No Meja</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Tanggal</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Pembayaran</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Menu</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Status Pesanan</th>
                        <th class="py-2 px-4 border border-[#E5E1DA] text-[14px] text-[#000000] text-left">Status Pembayaran</th>
                        <th class="py-2 px-4 border border-[#E5E1DA]  text-[14px] text-[#000000] text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="bg-white">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-[#F4F4F5]">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-white">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>

                    <tr class="bg-[#F4F4F5]">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>
                    <tr class="bg-white">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>
                    <tr class="bg-[#F4F4F5]">
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">#105482</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Alexandra bell</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">01</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">2/02/2025 10.00</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Qris</td>
                        <td class="py-2 px-4 border border-[#E5E1DA] text-[14px]">Bokso, Es Teh</td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[100px] h-[35px] text-[14px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-full">
                                Diproses
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <div class="flex items-center justify-center w-[110px] h-[35px] text-[14px] font-semibold text-white bg-[#20B149] rounded-[5px]">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="py-2 px-4 border border-[#E5E1DA]">
                            <a href="/dapur/detailriwayatpesanan-dapur" class="py-[5px] px-[10px] bg-[#434BE1] rounded-md text-[14px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </a>
                            <button class="py-[5px] px-[10px] bg-[#20B149] rounded-md text-[14px] text-[#FFFFFF]">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                            </button>
                        </td>
                    </tr>


                </tbody>
            </table>
        </div>
    </div>

    </div>

@endsection

<script>
</script>
