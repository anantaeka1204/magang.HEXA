<header id="header-kasir" class="flex justify-between items-center px-6 bg-white shadow-lg h-[100px]">
    <!-- Hallo Kasir -->
    <h1 class="font-bold text-[32px] text-black ml-[30px] mr-[100px]">TapEats</h1>

    <!-- Bagian Tengah: Navigasi -->
    <nav class="flex items-center space-x-[50px] mr-auto">
        <!-- Menu (Active) -->
        <a href="/dapur/dashboard-dapur" data-page="kasir-menu" class="kasir-header flex items-center px-[30px] space-x-4 text-black hover:bg-[#FADA7A] rounded-lg py-[10px]">
            <img src="/images/menu-pelanggan-hitam.png" alt="gambar" class="w-[39px] h-[33px]">
            <span class="text-[16px] font-medium">Menu</span>
        </a>

        <!-- Riwayat Pesanan -->
        <a href="/dapur/riwayatpesananall-dapur" data-page="kasir-riwayatpesanan" class="kasir-header flex items-center px-[30px] space-x-4 text-black hover:bg-[#FADA7A] rounded-lg py-[10px]">
            <img src="/images/dapur-riwayatpesanan.png" alt="gambar" class="w-[40px] h-[33px]">
            <span class="text-[16px] font-medium">Riwayat Pesanan</span>
        </a>
    </nav>

    <!-- Profil -->
    <div class="flex items-center mr-[20px] gap-[30px]">
        <!--<a href="#" class="py-[10px] px-[10px] bg-[#FFFFFF] rounded-md text-[14px] text-[#000000] inline-flex items-center gap-x-2 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M5.83301 18.3327C5.37467 18.3327 4.98245 18.1696 4.65634 17.8435C4.33023 17.5174 4.1669 17.1249 4.16634 16.666C4.16579 16.2071 4.32912 15.8149 4.65634 15.4893C4.98356 15.1638 5.37579 15.0005 5.83301 14.9993C6.29023 14.9982 6.68273 15.1616 7.01051 15.4893C7.33829 15.8171 7.50134 16.2093 7.49967 16.666C7.49801 17.1227 7.33495 17.5152 7.01051 17.8435C6.68606 18.1718 6.29356 18.3349 5.83301 18.3327ZM14.1663 18.3327C13.708 18.3327 13.3158 18.1696 12.9897 17.8435C12.6636 17.5174 12.5002 17.1249 12.4997 16.666C12.4991 16.2071 12.6625 15.8149 12.9897 15.4893C13.3169 15.1638 13.7091 15.0005 14.1663 14.9993C14.6236 14.9982 15.0161 15.1616 15.3438 15.4893C15.6716 15.8171 15.8347 16.2093 15.833 16.666C15.8313 17.1227 15.6683 17.5152 15.3438 17.8435C15.0194 18.1718 14.6269 18.3349 14.1663 18.3327ZM5.12467 4.99935L7.12467 9.16602H12.958L15.2497 4.99935H5.12467ZM4.33301 3.33268H16.6247C16.9441 3.33268 17.1872 3.47518 17.3538 3.76018C17.5205 4.04518 17.5275 4.33324 17.3747 4.62435L14.4163 9.95768C14.2636 10.2355 14.0588 10.4507 13.8022 10.6035C13.5455 10.7563 13.2641 10.8327 12.958 10.8327H6.74967L5.83301 12.4993H15.833V14.166H5.83301C5.20801 14.166 4.73579 13.8918 4.41634 13.3435C4.0969 12.7952 4.08301 12.2499 4.37467 11.7077L5.49967 9.66602L2.49967 3.33268H0.833008V1.66602H3.54134L4.33301 3.33268Z" fill="black"/>
              </svg>
            <span class="ml-1 font-medium text-[16px]">Keranjang</span>
        </a>-->
        <a href="#" class="py-[10px] px-[10px] bg-[#FFFFFF] rounded-md text-[14px] text-[#CA2A2A] inline-flex items-center gap-x-2 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M7.5 17.5H4.16667C3.72464 17.5 3.30072 17.3244 2.98816 17.0118C2.6756 16.6993 2.5 16.2754 2.5 15.8333V4.16667C2.5 3.72464 2.6756 3.30072 2.98816 2.98816C3.30072 2.6756 3.72464 2.5 4.16667 2.5H7.5" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11.667 5.83268L7.50033 9.99935L11.667 14.166" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M7.5 10H17.5" stroke="#CA2A2A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span class="ml-1 font-medium text-[16px]">Logout</span>
        </a>
        <!-- Foto Profil -->
        <img id="profileButton" src="/images/profil.jpg" alt="Profil" class="object-cover w-[44px] h-[44px] rounded-full cursor-pointer">
    </div>

</header>

<script>
   document.addEventListener("DOMContentLoaded", function () {
const sidebarItems = document.querySelectorAll(".kasir-header");
let activePage = localStorage.getItem("activeKasir");

// Jika ada halaman tersimpan di localStorage, gunakan itu untuk menyorot menu
if (activePage) {
    sidebarItems.forEach(item => {
        item.classList.remove("bg-[#FADA7A]");
        if (item.getAttribute("href") === activePage) {
            item.classList.add("bg-[#FADA7A]");
        }
    });
}

// Tambahkan event listener untuk menyimpan pilihan ke localStorage
sidebarItems.forEach(item => {
    item.addEventListener("click", function (event) {
        localStorage.setItem("activeKasir", this.getAttribute("href"));

        // Hapus warna dari semua item dan tambahkan ke yang diklik
        sidebarItems.forEach(i => i.classList.remove("bg-[#FADA7A]"));
        this.classList.add("bg-[#FADA7A]");
    });
});
});


//Pop Up Butto  Logout
const profileButton = document.getElementById('profileButton');
const logoutPopup = document.getElementById('logoutPopup');

profileButton.addEventListener('click', () => {
    logoutPopup.classList.toggle('hidden');
});

// Klik di luar popup untuk menutup
document.addEventListener('click', (event) => {
    if (!profileButton.contains(event.target) && !logoutPopup.contains(event.target)) {
        logoutPopup.classList.add('hidden');
    }
});
</script>



