
@extends('layout.master-dapur')

@section('title-dapur', 'Detail Riwayat Pesanan')

@section('content')

<div class="relative pt-[20px] md:px-[30px] lg:px-[50px] xl:px-[50px] content">

    <div class="flex items-center gap-[30px]">
        <a href="/dapur/">
            <!-- Icons Back -->
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
            </svg>
        </a>
        <span class="font-bold text-[24px] ml-2">Detail Pesanan</span>
    </div>

    <div class="pt-[20px]"></div>

    <div class="pt-2 pb-2 p-14">
        <div class="flex items-center justify-between w-full p-4 border-[#E5E1DA] border rounded-lg">
            <div class="flex flex-col">
                <strong class="text-[16px] font-semibold">Antrian Pesanan #105482</strong>
                <span class="px-[10px] py-[3px] mt-1 text-[12px] text-[#EFB036] bg-[#FFFBEB] rounded-[4px] w-fit">Meja 01</span>
            </div>
            <!--Menunggu Konfirmasi-->
            <div class="flex items-center justify-center px-[10px] py-[3px] text-[12px] w-[191px] text-black text-medium border-2 border-[#CA2A2A] bg-[rgba(202,42,42,0.45)] rounded-[10px]">Menunggu Konfirmasi</div>
            <!--Dikonfirmasi-->
            <!--<div class="px-[30px] py-1 text-[14px] text-black border-2 border-[#6CB56B] bg-[rgba(108,181,107,0.45)] rounded-xl">Dikonfirmasi</div>-->
        </div>
    </div>

    <div class="pt-[20px]"></div>

    <div class="pt-2 pb-2 p-14">
        <div class="w-full p-6 border-[#E5E1DA] border">
            <div class="flex flex-col justify-between md:flex-row">
                <!-- Bagian Kiri -->
                <div class="w-full space-y-4 md:w-1/5">
                    <div>
                        <p class="font-semibold text-[10px]">Nama Pelanggan</p>
                        <p class="text-[#5E6470] text-[10px] font-semibold">Alexandra Bell</p>
                    </div>
                    <div>
                        <p class="font-semibold text-[10px]">Pemesanan</p>
                        <p class="text-[#5E6470] text-[10px] font-semibold">#105482</p>
                    </div>
                    <div>
                        <p class="font-semibold text-[10px]">Tanggal Pesan</p>
                        <p class="text-[#5E6470] text-[10px] font-semibold">07 Februari, 2025</p>
                    </div>
                </div>

                <!-- Bagian Tabel -->
                <div class="w-full">
                    <div class="overflow-hidden border rounded-[12px]">
                        <table class="w-full">
                            <thead>
                                <tr>
                                    <th class="w-[70%] p-2 text-left text-[10px] text-semibold">List Menu</th>
                                    <th class="w-[15%] p-2 text-center text-[10px] text-semibold">Jumlah</th>
                                    <th class="w-[15%] p-2 text-center text-[10px] text-semibold">Sub Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold text-[10px]">Bakso Campur</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">1</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">Rp 15.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold text-[10px]">Rawon</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">3</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">Rp 22.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold text-[10px]">Es Teh</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">1</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">Rp 4.000</td>
                                </tr>
                                <tr class="border-t">
                                    <td class="p-2 font-semibold text-[10px]">Jeruk Panas</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">3</td>
                                    <td class="p-2 text-center text-[10px] font-semibold">Rp 6.000</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-t bg-[#F9FAFC]">
                                    <td class="p-2"></td>
                                    <td class="p-2 text-center font-bold text-[#4358D1] text-[10px]">Total Harga</td>
                                    <td class="p-2 text-center font-bold text-[#4358D1] text-[10px]">Rp. 103.000</td>
                                </tr>
                            </tfoot>
                        </table>


                    </div>
                </div>
            </div>

            <!-- Unduh Nota -->
            <div class="flex justify-end mt-6 md:mr-[0px] lg:mr-[30px] xl:mr-[105px]">
                <button class="px-[10px] py-[3px] w-[160px] text-white bg-[#1408FF] rounded-[5px] font-medium text-[12px]">Unduh Nota</button>
            </div>

        </div>


    </div>


<div>

@endsection
