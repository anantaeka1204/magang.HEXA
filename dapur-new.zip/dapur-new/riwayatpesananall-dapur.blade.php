@extends('layout.master-dapur')

@section('title-dapur', 'Riwayat Semua Pesanan')

@section('content')

<div class="relative pt-[20px] md:px-[30px] lg:px-[50px] xl:px-[50px] content">

     <div class="flex items-center justify-between mb-[20px]">
        <!-- Daftar Pesanan -->
        <h2 class="text-[24px] font-bold">Daftar Pesanan</h2>

        <!--Notifikasi Masuk-->
        <div id="notification-masuk" class="flex items-center rounded-[5px] bg-[#FFF6DA] text-black">
            <div class="flex items-center py-2 md:px-[40px] lg:px-[80px] xl:px-[80px]">
                <span class="mr-2">
                    <!-- Icons Garpu Sendok -->
                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                        <g clip-path="url(#clip0_935_399)">
                          <path d="M10.2575 0.644531C10.4282 0.644531 10.576 0.706911 10.7007 0.831671C10.8255 0.956431 10.8879 1.10417 10.8879 1.2749V8.20892C10.8879 8.55693 10.8222 8.88196 10.6909 9.18401C10.5596 9.48606 10.379 9.752 10.1492 9.98182C9.91935 10.2116 9.65013 10.3922 9.34152 10.5235C9.0329 10.6549 8.70787 10.7238 8.36642 10.7304V20.1859C8.36642 20.3566 8.30404 20.5043 8.17928 20.6291C8.05452 20.7538 7.90678 20.8162 7.73606 20.8162C7.56533 20.8162 7.41759 20.7538 7.29283 20.6291C7.16807 20.5043 7.10569 20.3566 7.10569 20.1859V10.7304C6.75768 10.7304 6.43264 10.6647 6.13059 10.5334C5.82854 10.4021 5.56261 10.2215 5.33279 9.99167C5.10297 9.76185 4.92239 9.49591 4.79107 9.19386C4.65974 8.89181 4.59079 8.5635 4.58423 8.20892V1.2749C4.58423 1.10417 4.64661 0.956431 4.77137 0.831671C4.89613 0.706911 5.04387 0.644531 5.21459 0.644531C5.38532 0.644531 5.53306 0.706911 5.65782 0.831671C5.78258 0.956431 5.84496 1.10417 5.84496 1.2749V8.20892C5.84496 8.38621 5.87779 8.55036 5.94345 8.70139C6.00912 8.85242 6.09776 8.98374 6.20939 9.09537C6.32102 9.207 6.45563 9.29892 6.61322 9.37115C6.77081 9.44338 6.93497 9.47621 7.10569 9.46965V1.2749C7.10569 1.10417 7.16807 0.956431 7.29283 0.831671C7.41759 0.706911 7.56533 0.644531 7.73606 0.644531C7.90678 0.644531 8.05452 0.706911 8.17928 0.831671C8.30404 0.956431 8.36642 1.10417 8.36642 1.2749V9.46965C8.54371 9.46965 8.70787 9.43682 8.85889 9.37115C9.00992 9.30549 9.14125 9.21685 9.25287 9.10522C9.3645 8.99359 9.45643 8.85898 9.52866 8.70139C9.60089 8.5438 9.63372 8.37964 9.62715 8.20892V1.2749C9.62715 1.10417 9.68953 0.956431 9.81429 0.831671C9.93905 0.706911 10.0868 0.644531 10.2575 0.644531ZM17.1915 0.644531V20.1859C17.1915 20.3566 17.1292 20.5043 17.0044 20.6291C16.8796 20.7538 16.7319 20.8162 16.5612 20.8162C16.3904 20.8162 16.2427 20.7538 16.1179 20.6291C15.9932 20.5043 15.9308 20.3566 15.9308 20.1859V14.5126C15.6879 14.5126 15.4252 14.5159 15.1429 14.5224C14.8605 14.529 14.5814 14.5257 14.3056 14.5126C14.0299 14.4994 13.7606 14.46 13.498 14.3944C13.2353 14.3287 13.0055 14.2269 12.8085 14.089C12.6115 13.9512 12.4507 13.764 12.3259 13.5276C12.2011 13.2912 12.142 12.9892 12.1486 12.6215V5.05709C12.1486 4.44642 12.2635 3.87515 12.4933 3.34328C12.7232 2.81141 13.0383 2.3452 13.4389 1.94466C13.8394 1.54412 14.3056 1.22893 14.8375 0.999112C15.3694 0.769291 15.9439 0.651098 16.5612 0.644531H17.1915ZM15.9308 1.96436C15.5631 2.03659 15.2282 2.16791 14.9262 2.35834C14.6241 2.54876 14.3582 2.78515 14.1284 3.0675C13.8985 3.34985 13.7212 3.65518 13.5965 3.9835C13.4717 4.31181 13.4093 4.66968 13.4093 5.05709V12.6215C13.4093 12.7922 13.4717 12.9399 13.5965 13.0647C13.7212 13.1895 13.869 13.2518 14.0397 13.2518H15.9308V1.96436Z" fill="black"/>
                        </g>
                        <defs>
                          <clipPath id="clip0_935_399">
                            <rect x="0.802002" y="0.644531" width="20.1717" height="20.1717" rx="5" fill="white"/>
                          </clipPath>
                        </defs>
                      </svg>
                </span>
                <span class="text-[16px] font-bold">Hallo Dapur</span>
                <span class="ml-2 text-[16px] font-normal">satu pesanan masuk</span>
            </div>
        </div>
    </div>

    <!-- Status Pesanan -->
    <div class="flex items-center space-x-12 pl-[6px]">
        <h6 class="text-[24px] font-bold">5</h6>
        <h6 class="text-[24px] font-bold">6</h6>
        <h6 class="text-[24px] font-bold">4</h6>

        <!-- Search -->
        <div id="search">
            <div class="relative flex max-w-md pl-6">
                <!-- Icon Pencarian -->
                <div class="absolute inset-y-0 flex items-center left-8">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                        <path d="M21.4172 19.2078L17.4508 15.2414C18.2703 14.0062 18.75 12.5273 18.75 10.9375C18.75 6.62969 15.2453 3.125 10.9375 3.125C6.62969 3.125 3.125 6.62969 3.125 10.9375C3.125 15.2453 6.62969 18.75 10.9375 18.75C12.5273 18.75 14.0062 18.2703 15.2414 17.4508L19.2078 21.4172C19.8172 22.0273 20.8078 22.0273 21.4172 21.4172C22.0273 20.807 22.0273 19.818 21.4172 19.2078ZM5.46875 10.9375C5.46875 7.92187 7.92187 5.46875 10.9375 5.46875C13.9531 5.46875 16.4062 7.92187 16.4062 10.9375C16.4062 13.9531 13.9531 16.4062 10.9375 16.4062C7.92187 16.4062 5.46875 13.9531 5.46875 10.9375Z" fill="black" fill-opacity="0.4"/>
                      </svg>
                </div>

                <!-- Input Field -->
                <input
                    id="search" name="search" type="text" autocomplete="off"
                    class="md:w-[280px]  lg:w-[334px]  xl:w-[334px]  h-[37px] flex-auto rounded-[16px] px-3.5 py-2 pl-10 text-black placeholder-[#A098AE] bg-[rgba(46,46,46,0.05)]"
                    placeholder="Cari Pelanggan">

            </div>
        </div>
    </div>

    <!-- Status Pesanan -->
    <div class="flex items-center gap-[26px]">
        <p class="font-medium text-[14px]">Baru</p>
        <p class="font-medium text-[14px]">Proses</p>
        <p class="font-medium text-[14px]">Selesai</p>
    </div>

</div>

<!-- Garis -->
<hr class="my-[20px] border-t-2 border-[#D9D9D9]">

    <!-- Button Status Pesanan -->
    <div id="button-status">
        <div class="flex md:px-[30px] lg:px-[50px] xl:px-[50px] mb-4 gap-[20px]">
            <a href="/dapur/riwayatpesananall-dapur" class="flex justify-center items-center text-center w-[134px] h-[31px] rounded-[5px] bg-[rgba(37,208,246,0.50)] hover:bg-[rgba(37,208,246,0.50)] text-black text-[14px] font-normal">Semua Pesanan</a>
            <a href="/dapur/riwayatpesananmenunggu-dapur" class="flex justify-center items-center text-center w-[97px] h-[31px] rounded-[5px] bg-[#E5E1DA] hover:bg-[rgba(202,42,42,0.45)] text-black  text-[14px] font-normal">Menunggu</a>
            <a href="/dapur/riwayatpesanandikonfirmasi-dapur" class="flex justify-center items-center text-center w-[114px] h-[31px] rounded-[5px] bg-[#E5E1DA] hover:bg-[rgba(67,75,225,0.45)] text-black text-[14px] font-normal">Dikonfirmasi</a>
            <a href="/dapur/riwayatpesananproses-dapur" class="flex justify-center items-center text-center w-[64px] h-[31px] rounded-[5px] bg-[#E5E1DA] hover:bg-[rgba(239,176,54,0.50)] text-black text-[14px] font-normal">Proses</a>
            <a href="/dapur/riwayatpesananselesai-dapur" class="flex justify-center items-center text-center w-[64px] h-[31px] rounded-[5px] bg-[#E5E1DA] hover:bg-[rgba(108,181,107,0.45)] text-black text-[14px] font-normal">Selesai</a>
        </div>
    </div>

    <!--Table-->
    <div class="relative p-[50px] pb-[30px] pt-[20px] content">

    <!-- Tabel Riwayat Pesanan -->
    <div class="overflow-hidden border rounded-[10px]">
        <table class="w-full rounded-[10px]">
                <thead>
                    <tr class="bg-[#F4F4F5]">
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-center">#</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">Nama Pelanggan</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">No Meja</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">Pembayaran</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">Menu</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">Status Pesanan</th>
                        <th class="py-2 px-4 border-r text-[13px] text-[#000000] text-left">Status Pembayaran</th>
                        <th class="py-2 px-4 text-[13px] text-[#000000] text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Riwayat 1 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal text-black bg-[rgba(202,42,42,0.45)] border-[#CA2A2A] border-2 rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#BB1717] rounded-[5px] mx-auto">
                                Belum Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 2 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal bg-[rgba(67,75,225,0.45)] border-2 border-[#434BE1] rounded-[15px] mx-auto">
                                Dikonfirmasi
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 3 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal text-black bg-[rgba(108,181,107,0.45)] border-2 border-[#6CB56B] rounded-[15px] mx-auto">
                                Selesai
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 4 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal text-black bg-[rgba(239,176,54,0.45)] border-2 border-[#EFB036] rounded-[15px] mx-auto">
                                Diproses
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#20B149] rounded-[5px] mx-auto">
                                Sudah Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[#20B149] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 5 -->
                    <tr class="bg-white border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal text-black bg-[rgba(202,42,42,0.45)] border-[#CA2A2A] border-2 rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#BB1717] rounded-[5px] mx-auto">
                                Belum Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                                <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                  </svg>
                                </a>
                                <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                  </svg>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <!-- Riwayat 6 -->
                    <tr class="bg-[#F4F4F5] border-t">
                        <td class="py-2 px-4 border-r text-[12px]">#105482</td>
                        <td class="py-2 px-4 border-r text-[12px]">Alexandra bell</td>
                        <td class="py-2 px-4 border-r text-[12px]">01</td>
                        <td class="py-2 px-4 border-r text-[12px]">Qris</td>
                        <td class="py-2 px-4 border-r text-[12px]">Bakso Campur, Es Teh</td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[80px] h-[24px] text-[11px] font-normal text-black bg-[rgba(202,42,42,0.45)] border-[#CA2A2A] border-2 rounded-[15px] mx-auto">
                                Menunggu
                            </div>
                        </td>
                        <td class="px-4 py-2 border-r">
                            <div class="flex items-center justify-center w-[95px] h-[24px] text-[11px] font-normal text-white bg-[#BB1717] rounded-[5px] mx-auto">
                                Belum Dibayar
                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <div class="flex items-center gap-1">
                              <a href="/dapur/detailriwayatpesanan-dapur" class="py-[2px] px-[5px] bg-[#434BE1] rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                  <path id="eyeInner" stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                              </a>
                              <button class="py-[2px] px-[5px] bg-[rgba(32,177,73,0.50)]  rounded-[5px] text-[#FFFFFF] inline-flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" class="w-[20px] h-[20px]" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                </svg>
                              </button>
                            </div>
                        </td>

                    </tr>


                </tbody>
            </table>
        </div>
    </div>

    </div>

@endsection

