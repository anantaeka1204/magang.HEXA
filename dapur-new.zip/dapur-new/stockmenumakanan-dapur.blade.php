@extends('layout.master-dapur')

@section('title-dapur', 'Stock Menu Makanan')

@section('content')

<div class="relative pt-[20px] md:px-[30px] lg:px-[50px] xl:px-[50px] content">

    <div class="flex items-center justify-between w-full">
        <!-- Tulisan Menu -->
        <div class="flex items-center">
            <span class="text-[32px] md:text-[32px] lg:text-[32px] xl:text-[32px] font-bold">Menu</span>
        </div>

        <!-- Search -->
        <div class="search-menu flex items-center px-2 py-2 rounded-[16px] w-[226px] h-[37px] border border-1 border-black">
            <input type="text" placeholder="Cari Menu"
                class="bg-transparent outline-none pl-2 placeholder-[#A098AE] text-[16px] font-normal w-[170px]">
            <!-- Button Search -->
            <button class="flex items-center justify-center ml-[10px] rounded-full icon-search">
                <!-- Icons Search -->
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                    <path d="M21.4172 19.2078L17.4508 15.2414C18.2703 14.0062 18.75 12.5273 18.75 10.9375C18.75 6.62969 15.2453 3.125 10.9375 3.125C6.62969 3.125 3.125 6.62969 3.125 10.9375C3.125 15.2453 6.62969 18.75 10.9375 18.75C12.5273 18.75 14.0062 18.2703 15.2414 17.4508L19.2078 21.4172C19.8172 22.0273 20.8078 22.0273 21.4172 21.4172C22.0273 20.807 22.0273 19.818 21.4172 19.2078ZM5.46875 10.9375C5.46875 7.92187 7.92187 5.46875 10.9375 5.46875C13.9531 5.46875 16.4062 7.92187 16.4062 10.9375C16.4062 13.9531 13.9531 16.4062 10.9375 16.4062C7.92187 16.4062 5.46875 13.9531 5.46875 10.9375Z" fill="black" fill-opacity="0.4"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- Garis -->
    <hr class="border mt-[20px] border-black/15">

        <!-- Button Menu Kategori -->
        <div class="pt-[20px] pb-[10px] overflow-x-auto set-scroll">
            <div class="flex gap-[10px]">
                <a href="/dapur/" class="semua-menu bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="text-[16px] font-medium">Semua Menu</span>
                </a>
                <a href="/dapur/stockmenumakanan-dapur" class="menu-makanan bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M5.32812 16.0742V19.0695C6.2433 20.1914 7.39682 21.0953 8.70492 21.7157C10.013 22.3361 11.4429 22.6574 12.8906 22.6563C16.2688 22.6563 19.2469 20.9406 21 18.3336V14.1352C20.4 18.075 16.9977 21.0938 12.8906 21.0938C9.48906 21.0938 6.57109 19.0234 5.32812 16.0742ZM19.5547 8.10626V6.76095C19.5521 6.46422 19.6007 6.16926 19.6984 5.88907C17.8774 4.11379 15.4338 3.12168 12.8906 3.12501C10.6147 3.12163 8.40971 3.91645 6.65937 5.3711L6.66328 5.41876L6.66406 5.43985V7.54923C7.43357 6.65072 8.38865 5.92963 9.46355 5.43561C10.5384 4.94159 11.7076 4.68636 12.8906 4.68751C15.6359 4.68751 18.0656 6.03595 19.5547 8.10626Z" fill="black"/>
                            <path d="M19.1406 12.8908C19.1406 14.5484 18.4821 16.1381 17.31 17.3102C16.1379 18.4823 14.5482 19.1408 12.8906 19.1408C11.233 19.1408 9.64331 18.4823 8.47121 17.3102C7.29911 16.1381 6.64062 14.5484 6.64062 12.8908C6.64062 11.2332 7.29911 9.64349 8.47121 8.47139C9.64331 7.29929 11.233 6.64081 12.8906 6.64081C14.5482 6.64081 16.1379 7.29929 17.31 8.47139C18.4821 9.64349 19.1406 11.2332 19.1406 12.8908ZM12.8906 18.3596C13.6088 18.3596 14.3199 18.2181 14.9834 17.9433C15.6469 17.6684 16.2498 17.2656 16.7576 16.7578C17.2654 16.25 17.6683 15.6471 17.9431 14.9836C18.2179 14.3201 18.3594 13.609 18.3594 12.8908C18.3594 12.1726 18.2179 11.4615 17.9431 10.798C17.6683 10.1345 17.2654 9.53164 16.7576 9.02382C16.2498 8.516 15.6469 8.11317 14.9834 7.83834C14.3199 7.56351 13.6088 7.42206 12.8906 7.42206C11.4402 7.42206 10.0492 7.99823 9.02363 9.02382C7.99805 10.0494 7.42188 11.4404 7.42188 12.8908C7.42188 14.3412 7.99805 15.7322 9.02363 16.7578C10.0492 17.7834 11.4402 18.3596 12.8906 18.3596ZM23.4297 6.20331C23.4297 5.50018 22.8594 4.92987 22.1562 4.92987C21.1406 4.92987 20.3281 5.75018 20.3359 6.758V11.0939C20.3359 12.0728 20.9031 12.9494 21.7812 13.3463V20.0783C21.7812 20.4846 22.1094 20.8127 22.5156 20.8127H22.6953C23.1016 20.8127 23.4297 20.4846 23.4297 20.0783V6.20331ZM5.32813 4.92987C5.18723 4.92987 5.0521 4.98584 4.95247 5.08547C4.85285 5.1851 4.79688 5.32022 4.79688 5.46112V7.56268C4.79688 7.71893 4.67188 7.83612 4.52344 7.83612C4.36719 7.83612 4.25 7.71112 4.25 7.56268V5.48456C4.25 5.1955 4.02344 4.93768 3.73438 4.92987C3.42969 4.92206 3.17969 5.16425 3.17969 5.46112V7.56268C3.17969 7.71893 3.05469 7.83612 2.90625 7.83612C2.75 7.83612 2.63281 7.71112 2.63281 7.56268V5.48456C2.63281 5.1955 2.40625 4.93768 2.11719 4.92987C1.8125 4.92206 1.5625 5.16425 1.5625 5.46112V9.03925C1.5625 9.74393 1.90391 10.3728 2.42891 10.765C2.89844 11.0299 2.89844 12.2424 2.89844 12.2424V20.0705C2.89844 20.4767 3.22656 20.8049 3.63281 20.8049H3.8125C4.21875 20.8049 4.54688 20.4767 4.54688 20.0705V12.2424C4.54688 12.2424 4.54688 11.0775 5.01641 10.765C5.28503 10.5645 5.5032 10.3041 5.6536 10.0045C5.804 9.70497 5.88248 9.37446 5.88281 9.03925V5.46112C5.8749 5.31876 5.81322 5.18471 5.71025 5.08609C5.60728 4.98747 5.4707 4.93163 5.32813 4.92987Z" fill="black"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Makanan</span>
                </a>
                <a href="/dapur/stockmenuminuman-dapur" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] 5px] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M15.0835 1.04199H20.8335V3.12533H16.646L15.9689 5.43991H20.9064L19.6439 23.9587H6.4762L5.56995 10.7066C3.61995 10.2743 2.0835 8.58262 2.0835 6.48158C2.0835 4.06491 4.07725 2.14199 6.49079 2.14199C8.546 2.14199 10.296 3.5347 10.772 5.43991H13.797L15.0835 1.04199ZM13.1877 7.52324H7.44287L7.6887 11.1503L11.9252 11.8389L13.1877 7.52324ZM12.496 14.042L7.83454 13.2847L8.42204 21.8753H17.697L18.1668 14.9837L12.5002 14.043L12.496 14.042ZM18.3095 12.8962L18.6762 7.52324H15.3585L13.996 12.1795L18.3095 12.8962ZM8.55329 5.43887C8.35212 5.06828 8.05386 4.75945 7.69052 4.54548C7.32717 4.33151 6.91244 4.22047 6.49079 4.22428C5.18766 4.22533 4.16683 5.25553 4.16683 6.48158C4.16683 7.31178 4.66683 8.06803 5.41787 8.45658L5.21266 5.43991L8.55329 5.43887Z" fill="black"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Minuman</span>
                </a>
                <a href="/dapur/stockmenusnack-dapur" class="menu-makanan bg-[#FFFFFF] hover:bg-[#FADA7A] border border-1 h-[45px] w-[175px] gap-2 rounded-[25px] shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] flex justify-center items-center">
                    <span class="flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <path d="M16.9937 4.11416C16.7926 3.54516 16.4272 3.04862 15.9437 2.68743C15.4603 2.32625 14.8805 2.11666 14.2778 2.0852C13.6752 2.05375 13.0767 2.20184 12.5583 2.51074C12.0399 2.81963 11.6248 3.27543 11.3655 3.82041C11.0426 4.49749 10.2312 5.11416 9.48325 5.18291C8.67402 5.25663 7.91441 5.60519 7.33079 6.17059C6.74718 6.736 6.37472 7.48417 6.27539 8.29066C6.17605 9.09715 6.35582 9.91335 6.7848 10.6035C7.21377 11.2936 7.86609 11.8161 8.63325 12.0839M8.63325 12.0839C8.30855 12.342 8.03991 12.6636 7.84378 13.0291C7.64765 13.3945 7.52814 13.7962 7.49258 14.2094C7.45701 14.6226 7.50613 15.0388 7.63693 15.4324C7.76774 15.826 7.97747 16.1888 8.2533 16.4985C8.52913 16.8083 8.86526 17.0585 9.24113 17.2339C9.61699 17.4092 10.0247 17.5061 10.4393 17.5185C10.8538 17.5308 11.2666 17.4585 11.6522 17.3059C12.0379 17.1533 12.3884 16.9236 12.6822 16.6308C12.7083 16.6058 12.7399 16.5872 12.7745 16.5765C12.8091 16.5659 12.8456 16.5635 12.8813 16.5696C12.917 16.5757 12.9507 16.59 12.9798 16.6115C13.0089 16.633 13.0326 16.661 13.0489 16.6933C13.4333 17.537 14.1319 18.1972 14.9958 18.5335C15.8598 18.8697 16.8209 18.8553 17.6745 18.4935C18.528 18.1316 19.2066 17.4508 19.5657 16.596C19.9247 15.7413 19.9359 14.7801 19.5968 13.9173M8.63325 12.0839C9.21938 11.62 9.95553 11.3875 10.7018 11.4307C11.4481 11.474 12.1525 11.7898 12.6812 12.3183M16.2749 7.28812C16.6821 6.88067 16.9657 6.36629 17.0929 5.80444C17.2201 5.2426 17.1857 4.65623 16.9937 4.11312C17.1467 3.68213 17.3947 3.29109 17.7193 2.96895C18.0439 2.64682 18.4369 2.40184 18.869 2.25216C19.3012 2.10248 19.7615 2.05193 20.2158 2.10426C20.6702 2.1566 21.1069 2.31047 21.4937 2.55448C21.8805 2.7985 22.2075 3.1264 22.4503 3.51391C22.6932 3.90142 22.8458 4.33861 22.8969 4.79309C22.9479 5.24758 22.896 5.70772 22.7451 6.13943C22.5941 6.57115 22.348 6.96338 22.0249 7.28707C21.7041 7.60791 21.7041 8.40478 22.0239 8.72457C22.4666 9.16735 22.7623 9.7357 22.8707 10.3524C22.9791 10.9691 22.8951 11.6042 22.63 12.1714C22.3648 12.7387 21.9315 13.2105 21.3888 13.5229C20.8461 13.8352 20.2205 13.9729 19.5968 13.9173M19.5968 13.9173C19.0694 13.8702 18.5633 13.6867 18.1283 13.3848C17.6932 13.0829 17.3442 12.673 17.1155 12.1954M2.08325 22.9162L8.33325 16.6662" stroke="black" stroke-width="1.5625" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span class="text-[16px] font-medium justify-start">Snack</span>
                </a>
            </div>
        </div>

    <!-- Menu Makanan -->
    <p class="font-semibold text-[20px] pt-[20px] pb-[20px]">Makanan</p>

        <!-- Menu Makanan -->
        <div class="grid items-center justify-around gap-[20px] grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5">

            <!-- Card 1 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Bakso Campur</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Isi: Pentol, tahu, gorengan</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                         <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="1" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/mie ayam.jpg" alt="Mie Ayam" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Mie Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Mie dengan topping potongan ayam berbumbu kecap</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                         <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="2" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/kare ayam.jpg" alt="Kari Ayam" class="object-cover w-[239px] h-[202px] saturate-0">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Kari Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Olahan ayam dengan kuah santan dan bumbu rempah khas</p>
                    <p class="text-[14px] text-[#CA2A2A] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok Habis</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 15.000</p>
                         <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="3" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

           <!-- Card 4 -->
           <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/rawon.jpg" alt="Rawon" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Rawon</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup kuah hitam dengan topping potongan daging sapi empuk</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 22.000</p>
                        <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="4" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 5 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/soto ayam.jpg" alt="Soto Ayam" class="object-cover w-[239px] h-[202px] saturate-0">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Soto Ayam</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup dengan topping potongan ayam suwir dan bihun</p>
                    <p class="text-[14px] text-[#CA2A2A] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok Habis</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 12.000</p>
                         <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="5" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 6 -->
            <div class="overflow-hidden bg-white rounded-[10px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.25)] w-[238px] h-[367px] relative mb-[10px] flex flex-col">
                <!-- Gambar -->
                <img src="/images/sup daging.jpg" alt="Sup Daging" class="object-cover w-[239px] h-[202px]">

                <!-- Konten Teks -->
                <div class="flex flex-col flex-grow p-4 pt-1">
                    <h2 class="text-[20px] font-bold">Sup Daging</h2>
                    <p class="text-[13px] font-light text-[#686D76]">Sup dengan topping potongan daging dan sayuran segar</p>
                    <p class="text-[14px] font-medium mt-[5px] absolute bottom-[70px] left-4">Stok: 50</p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="font-semibold text-[18px]">Rp. 20.000</p>
                         <!-- Edit Stock -->
                        <div class="flex items-center justify-center">
                            <a data-item-id="6" href="" class="editStockBtn w-[90px] h-[30px] rounded-lg bg-[#FADA7A] flex items-center justify-center gap-[5px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span class="text-[11px] font-medium">Edit Stock</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Modal Pop-up Edit Stock -->
<div id="editstockModal" class="fixed inset-0 items-center justify-center hidden bg-black bg-opacity-50">
    <!-- Modal Content -->
    <div class="bg-white p-6 rounded-[10px] shadow-lg w-[595px] h-[419px]">
       <h2 class="mb-[70px] text-[28px] font-medium text-center mt-[30px]">Edit stock bakso campur</h2>

       <!-- Stock Input -->
       <div class="flex items-center justify-center border rounded-[5px] w-[285px] h-[54px] mx-auto border-black">
            <!-- Button Minus -->
           <button id="decreaseStock" class="pr-[40px]">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="3" viewBox="0 0 28 3" fill="none">
                   <path d="M26.6562 2.11055H1.34375C0.78125 2.11055 0.265625 1.84492 0.265625 1.49961C0.265625 1.18086 0.734375 0.888672 1.34375 0.888672H26.6562C27.2187 0.888672 27.7344 1.1543 27.7344 1.49961C27.7344 1.81836 27.2187 2.11055 26.6562 2.11055Z" fill="black"/>
               </svg>
           </button>

           <!-- Border Vertikal -->
           <div class="h-[53px] border-l border-black"></div>

           <span id="stockValue" class="px-[30px] text-[32px] text-medium">1</span>

           <!-- Border Vertikal -->
           <div class="h-[53px] border-l border-black"></div>

           <!-- Button Plus -->
           <button id="increaseStock" class="pl-[40px]">
               <svg xmlns="http://www.w3.org/2000/svg" width="25" height="20" viewBox="0 0 31 31" fill="none">
                   <g clip-path="url(#clip0_1413_2938)">
                     <path d="M28.2019 14.4687H16.155V2.375C16.155 1.8125 15.6863 1.29688 15.0769 1.29688C14.5144 1.29688 13.9988 1.76562 13.9988 2.375V14.4687H1.9519C1.3894 14.4687 0.873779 14.9375 0.873779 15.5469C0.873779 16.1094 1.34253 16.625 1.9519 16.625H14.0457V28.625C14.0457 29.1875 14.5144 29.7031 15.1238 29.7031C15.6863 29.7031 16.2019 29.2344 16.2019 28.625V16.5781H28.2019C28.7644 16.5781 29.28 16.1094 29.28 15.5C29.28 14.9375 28.7644 14.4687 28.2019 14.4687Z" fill="#111928"/>
                   </g>
                   <defs>
                     <clipPath id="clip0_1413_2938">
                       <rect width="30" height="30" fill="white" transform="translate(0.0769043 0.5)"/>
                     </clipPath>
                   </defs>
               </svg>
           </button>
       </div>

       <!-- Action Buttons -->
       <div class="flex justify-center mt-[100px] gap-[10px]">
           <button id="confirmStock" class="w-full bg-[#EFB036] py-[3px] px-[10px] rounded text-medium text-[20px]">Oke</button>
           <button id="closeModal" class="w-full bg-[#E5E1DA] py-[3px] px-[10px] rounded text-medium text-[20px]">Batal</button>
       </div>
   </div>
</div>


</div>

@endsection

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const editStockBtns = document.querySelectorAll(".editStockBtn");
        const modal = document.getElementById("editstockModal");
        const closeModal = document.getElementById("closeModal");
        const confirmStock = document.getElementById("confirmStock");
        const decreaseStock = document.getElementById("decreaseStock");
        const increaseStock = document.getElementById("increaseStock");
        const stockValue = document.getElementById("stockValue");

        let stockCount = parseInt(stockValue.textContent);

        editStockBtns.forEach(btn => {
            btn.addEventListener("click", function (event) {
                event.preventDefault();
                modal.classList.remove("hidden");
                modal.classList.add("flex");
            });
        });

        closeModal.addEventListener("click", function () {
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        });

        increaseStock.addEventListener("click", function () {
            stockCount++;
            stockValue.textContent = stockCount;
        });

        decreaseStock.addEventListener("click", function () {
            if (stockCount > 1) {
                stockCount--;
                stockValue.textContent = stockCount;
            }
        });

        confirmStock.addEventListener("click", function () {
            alert("Stock berhasil diperbarui: " + stockCount);
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        });
    });
</script>


